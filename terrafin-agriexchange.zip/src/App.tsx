import React, { useState } from 'react';
import {
  ProduceListing,
  EscrowContract,
  InputLoanApplication,
  ParametricPolicy,
  ClimateTelemetryData,
  WalletTransaction,
  RegionCorridor,
  Currency,
} from './types';
import {
  INITIAL_PRODUCE_LISTINGS,
  INITIAL_ESCROW_CONTRACTS,
  INPUT_PACKAGES,
  INITIAL_INPUT_LOANS,
  INITIAL_PARAMETRIC_POLICIES,
  INITIAL_CLIMATE_TELEMETRY,
  INITIAL_WALLET_TRANSACTIONS,
  INITIAL_COOPERATIVES,
} from './data/mockData';
import { Header } from './components/Header';
import { HeroOverview } from './components/HeroOverview';
import { MarketplaceView } from './components/MarketplaceView';
import { EscrowContractsView } from './components/EscrowContractsView';
import { InputFinancingView } from './components/InputFinancingView';
import { ParametricInsuranceView } from './components/ParametricInsuranceView';
import { CooperativeHubView } from './components/CooperativeHubView';
import { WalletView } from './components/WalletView';
import { ShieldCheck, Globe, Sprout, CloudRain } from 'lucide-react';

export default function App() {
  // Navigation & Localization State
  const [activeTab, setActiveTab] = useState<'marketplace' | 'escrow' | 'financing' | 'insurance' | 'cooperatives' | 'wallet'>('marketplace');
  const [activeCorridor, setActiveCorridor] = useState<RegionCorridor>('all');
  const [currency, setCurrency] = useState<Currency>('USD');

  // Domain Entities State
  const [listings, setListings] = useState<ProduceListing[]>(INITIAL_PRODUCE_LISTINGS);
  const [contracts, setContracts] = useState<EscrowContract[]>(INITIAL_ESCROW_CONTRACTS);
  const [loans, setLoans] = useState<InputLoanApplication[]>(INITIAL_INPUT_LOANS);
  const [policies, setPolicies] = useState<ParametricPolicy[]>(INITIAL_PARAMETRIC_POLICIES);
  const [telemetry, setTelemetry] = useState<Record<string, ClimateTelemetryData>>(INITIAL_CLIMATE_TELEMETRY);
  const [transactions, setTransactions] = useState<WalletTransaction[]>(INITIAL_WALLET_TRANSACTIONS);

  // Treasury Balances
  const [availableBalanceUsd, setAvailableBalanceUsd] = useState<number>(185000);
  const [lockedEscrowUsd, setLockedEscrowUsd] = useState<number>(91500);
  const [creditLineAvailableUsd, setCreditLineAvailableUsd] = useState<number>(50000);
  const [insuranceReservesUsd, setInsuranceReservesUsd] = useState<number>(24000);

  // Modal State
  const [isWalletOpen, setIsWalletOpen] = useState(false);
  const [isCreateListingOpen, setIsCreateListingOpen] = useState(false);

  // Climate Simulation State
  const [isSimulatingAnomaly, setIsSimulatingAnomaly] = useState(false);
  const [anomalyType, setAnomalyType] = useState<'drought' | 'deluge' | null>(null);

  // Handler: Initiate Escrow Trade
  const handleInitiateEscrow = (listing: ProduceListing, volumeMt: number) => {
    const totalAmountUsd = listing.pricePerMtUsd * volumeMt;
    const contractId = `CTR-2026-${Math.floor(100 + Math.random() * 900)}`;

    const newContract: EscrowContract = {
      id: contractId,
      listingId: listing.id,
      cropName: `${listing.cropName} (${volumeMt} MT Lot)`,
      volumeMt,
      buyerName: 'Global Commodities Trade Partner',
      farmerName: listing.farmerName,
      cooperativeName: listing.cooperativeName,
      totalAmountUsd,
      currency: 'USD',
      escrowStatus: 'deposit_locked',
      depositTimestamp: new Date().toISOString().replace('T', ' ').substring(0, 16) + ' UTC',
      inspectionWindowHours: 48,
      logisticsProvider: 'Maersk / Bolloré Agrilogistics',
      trackingNumber: `AGRI-${Math.floor(100000 + Math.random() * 900000)}`,
      moistureVerifiedPercent: listing.moistureContentPercent,
      gradeVerified: listing.qualityGrade,
      notes: `Smart escrow earnest deposit of $${totalAmountUsd.toLocaleString()} held safely in vault.`,
    };

    setContracts([newContract, ...contracts]);
    setAvailableBalanceUsd((prev) => Math.max(0, prev - totalAmountUsd));
    setLockedEscrowUsd((prev) => prev + totalAmountUsd);

    const newTxn: WalletTransaction = {
      id: `TXN-${Math.floor(1000 + Math.random() * 9000)}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
      type: 'escrow_lock',
      description: `Escrow deposit locked for ${listing.cropName} (${volumeMt} MT)`,
      amountUsd: -totalAmountUsd,
      currency: 'USD',
      localAmount: -totalAmountUsd,
      status: 'completed',
      referenceId: contractId,
      rail: 'Internal Escrow',
    };
    setTransactions([newTxn, ...transactions]);

    // Automatically transition to Escrow tab so the user sees the new contract in real time
    setActiveTab('escrow');
  };

  // Handler: Advance Contract (Log Port Arrival & SGS Lab Inspection)
  const handleAdvanceContract = (contractId: string) => {
    setContracts(
      contracts.map((c) => {
        if (c.id === contractId && c.escrowStatus === 'in_transit') {
          return {
            ...c,
            escrowStatus: 'quality_inspected',
            notes: 'Vessel arrived at destination depot. SGS inspection certificate #8812 verified moisture within tolerance.',
          };
        }
        return c;
      })
    );
  };

  // Handler: Release Escrow Funds to Farmer/Coop
  const handleReleaseFunds = (contractId: string) => {
    const target = contracts.find((c) => c.id === contractId);
    if (!target) return;

    setContracts(
      contracts.map((c) => {
        if (c.id === contractId) {
          return {
            ...c,
            escrowStatus: 'disbursed_to_farmer',
            disbursedTimestamp: new Date().toISOString().replace('T', ' ').substring(0, 16) + ' UTC',
            notes: `Funds of $${c.totalAmountUsd.toLocaleString()} successfully settled into ${c.cooperativeName} treasury.`,
          };
        }
        return c;
      })
    );

    setLockedEscrowUsd((prev) => Math.max(0, prev - target.totalAmountUsd));

    const newTxn: WalletTransaction = {
      id: `TXN-${Math.floor(1000 + Math.random() * 9000)}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
      type: 'escrow_payout',
      description: `Escrow payout released to ${target.cooperativeName} (${target.cropName})`,
      amountUsd: target.totalAmountUsd,
      currency: 'USD',
      localAmount: target.totalAmountUsd,
      status: 'completed',
      referenceId: contractId,
      rail: 'SWIFT/Wire',
    };
    setTransactions([newTxn, ...transactions]);
  };

  // Handler: Apply for Input Loan
  const handleApplyLoan = (
    loanData: Omit<InputLoanApplication, 'id' | 'appliedDate' | 'status' | 'creditScore' | 'creditFactors'>
  ) => {
    const loanId = `LOAN-${loanData.corridor.toUpperCase().substring(0, 2)}-${Math.floor(1000 + Math.random() * 9000)}`;
    const newLoan: InputLoanApplication = {
      ...loanData,
      id: loanId,
      appliedDate: new Date().toISOString().split('T')[0],
      status: 'disbursed',
      creditScore: 805,
      creditFactors: {
        ndviConsistencyScore: 95,
        repaymentHistoryScore: 100,
        coopTenureScore: 90,
        soilHealthScore: 84,
      },
    };

    setLoans([newLoan, ...loans]);

    const newTxn: WalletTransaction = {
      id: `TXN-${Math.floor(1000 + Math.random() * 9000)}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
      type: 'loan_disbursal',
      description: `Pre-Season Input Financing Disbursed to ${loanData.farmerName} (${loanData.inputPackageName})`,
      amountUsd: loanData.principalAmountUsd,
      currency: 'USD',
      localAmount: loanData.principalAmountUsd,
      status: 'completed',
      referenceId: loanId,
      rail: loanData.corridor === 'africa' ? 'M-Pesa Kenya' : loanData.corridor === 'india' ? 'UPI India' : 'Pix Brazil',
    };
    setTransactions([newTxn, ...transactions]);
  };

  // Handler: Repay Input Loan
  const handleRepayLoan = (loanId: string) => {
    setLoans(
      loans.map((l) => {
        if (l.id === loanId) {
          return { ...l, status: 'repaid' };
        }
        return l;
      })
    );
  };

  // Handler: Simulate Weather Anomaly for Parametric Insurance
  const handleSimulateWeatherAnomaly = (type: 'drought' | 'deluge' | 'reset') => {
    if (type === 'reset') {
      setIsSimulatingAnomaly(false);
      setAnomalyType(null);
      setTelemetry(INITIAL_CLIMATE_TELEMETRY);
      return;
    }

    setIsSimulatingAnomaly(true);
    setAnomalyType(type);

    setTelemetry((prev) => {
      const updated = { ...prev };
      const currentCorridorKey = activeCorridor === 'all' ? 'africa' : activeCorridor;

      if (type === 'drought') {
        updated[currentCorridorKey] = {
          ...updated[currentCorridorKey],
          currentSeasonalRainfallMm: 38.2, // Below 60mm trigger!
          soilMoisturePercent: 12.1,
          currentNdviIndex: 0.42,
          riskCondition: 'severe_drought',
        };
      } else if (type === 'deluge') {
        updated[currentCorridorKey] = {
          ...updated[currentCorridorKey],
          currentSeasonalRainfallMm: 215.0, // Above 180mm trigger!
          soilMoisturePercent: 88.4,
          riskCondition: 'excess_moisture',
        };
      }
      return updated;
    });
  };

  // Handler: Trigger Parametric Insurance Claim Payout
  const handleTriggerPolicyPayout = (policyId: string) => {
    const targetPolicy = policies.find((p) => p.id === policyId);
    if (!targetPolicy) return;

    const payoutAmount = targetPolicy.sumInsuredUsd;
    const txHash = `ORCL-CLAIM-${Math.random().toString(36).substring(2, 10).toUpperCase()}`;

    setPolicies(
      policies.map((p) => {
        if (p.id === policyId) {
          return {
            ...p,
            status: 'triggered_paid',
            payoutAmountUsd: payoutAmount,
            payoutTxHash: txHash,
            payoutTimestamp: new Date().toISOString().replace('T', ' ').substring(0, 16) + ' UTC',
          };
        }
        return p;
      })
    );

    setAvailableBalanceUsd((prev) => prev + payoutAmount);
    setInsuranceReservesUsd((prev) => prev + payoutAmount);

    const newTxn: WalletTransaction = {
      id: `TXN-${Math.floor(1000 + Math.random() * 9000)}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
      type: 'insurance_claim',
      description: `Satellite Oracle Automated Claim Payout for ${targetPolicy.farmerOrCoopName} (${targetPolicy.cropInsured})`,
      amountUsd: payoutAmount,
      currency: 'USD',
      localAmount: payoutAmount,
      status: 'completed',
      referenceId: txHash,
      rail: targetPolicy.corridor === 'africa' ? 'M-Pesa Kenya' : targetPolicy.corridor === 'india' ? 'UPI India' : 'Pix Brazil',
    };
    setTransactions([newTxn, ...transactions]);
  };

  // Handler: Add New Parametric Policy
  const handleAddNewPolicy = (
    newPolicyData: Omit<ParametricPolicy, 'id' | 'status' | 'payoutAmountUsd' | 'payoutTxHash' | 'payoutTimestamp'>
  ) => {
    const policyId = `POL-${newPolicyData.corridor.toUpperCase().substring(0, 2)}-${Math.floor(100 + Math.random() * 900)}`;
    const newPolicy: ParametricPolicy = {
      ...newPolicyData,
      id: policyId,
      status: 'active',
    };
    setPolicies([newPolicy, ...policies]);
  };

  // Handler: Add New Produce Listing
  const handleAddNewListing = (newListingData: Omit<ProduceListing, 'id' | 'status'>) => {
    const listingId = `LIST-${newListingData.corridor.toUpperCase().substring(0, 2)}-${Math.floor(100 + Math.random() * 900)}`;
    const newListing: ProduceListing = {
      ...newListingData,
      id: listingId,
      status: 'available',
    };
    setListings([newListing, ...listings]);
  };

  // Handler: Wallet Deposit
  const handleDeposit = (amountUsd: number, rail: string) => {
    setAvailableBalanceUsd((prev) => prev + amountUsd);
    const newTxn: WalletTransaction = {
      id: `TXN-${Math.floor(1000 + Math.random() * 9000)}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
      type: 'deposit',
      description: `Treasury Escrow Deposit via ${rail}`,
      amountUsd,
      currency: 'USD',
      localAmount: amountUsd,
      status: 'completed',
      referenceId: `DEP-${Math.random().toString(36).substring(2, 8).toUpperCase()}`,
      rail: rail as any,
    };
    setTransactions([newTxn, ...transactions]);
  };

  // Handler: Wallet Withdraw
  const handleWithdraw = (amountUsd: number, destination: string) => {
    setAvailableBalanceUsd((prev) => Math.max(0, prev - amountUsd));
    const newTxn: WalletTransaction = {
      id: `TXN-${Math.floor(1000 + Math.random() * 9000)}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
      type: 'withdrawal',
      description: `Settlement Payout to ${destination}`,
      amountUsd: -amountUsd,
      currency: 'USD',
      localAmount: -amountUsd,
      status: 'completed',
      referenceId: `WTH-${Math.random().toString(36).substring(2, 8).toUpperCase()}`,
      rail: 'SWIFT/Wire',
    };
    setTransactions([newTxn, ...transactions]);
  };

  return (
    <div className="min-h-screen bg-stone-50 text-stone-900 flex flex-col justify-between">
      <div>
        {/* Top Bar Contract (3 zones) */}
        <Header
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          activeCorridor={activeCorridor}
          setActiveCorridor={setActiveCorridor}
          currency={currency}
          setCurrency={setCurrency}
          walletBalanceUsd={availableBalanceUsd}
          onOpenWallet={() => setIsWalletOpen(true)}
          onOpenNewListing={() => setIsCreateListingOpen(true)}
        />

        {/* Hero Section & Corridor Switcher */}
        <HeroOverview
          activeCorridor={activeCorridor}
          setActiveCorridor={setActiveCorridor}
          currency={currency}
          onExploreTab={(tab) => setActiveTab(tab)}
        />

        {/* Main Content Area */}
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          {activeTab === 'marketplace' && (
            <MarketplaceView
              listings={listings}
              activeCorridor={activeCorridor}
              currency={currency}
              onInitiateEscrow={handleInitiateEscrow}
              onAddNewListing={handleAddNewListing}
              isCreateModalOpen={isCreateListingOpen}
              setIsCreateModalOpen={setIsCreateListingOpen}
            />
          )}

          {activeTab === 'escrow' && (
            <EscrowContractsView
              contracts={contracts}
              currency={currency}
              onAdvanceContract={handleAdvanceContract}
              onReleaseFunds={handleReleaseFunds}
            />
          )}

          {activeTab === 'financing' && (
            <InputFinancingView
              loans={loans}
              packages={INPUT_PACKAGES}
              activeCorridor={activeCorridor}
              currency={currency}
              onApplyLoan={handleApplyLoan}
              onRepayLoan={handleRepayLoan}
            />
          )}

          {activeTab === 'insurance' && (
            <ParametricInsuranceView
              policies={policies}
              telemetry={telemetry}
              activeCorridor={activeCorridor}
              currency={currency}
              onSimulateWeatherAnomaly={handleSimulateWeatherAnomaly}
              onTriggerPolicyPayout={handleTriggerPolicyPayout}
              onAddNewPolicy={handleAddNewPolicy}
              isSimulatingAnomaly={isSimulatingAnomaly}
              anomalyType={anomalyType}
            />
          )}

          {activeTab === 'cooperatives' && (
            <CooperativeHubView
              cooperatives={INITIAL_COOPERATIVES}
              activeCorridor={activeCorridor}
            />
          )}
        </main>
      </div>

      {/* Global Settlement Wallet Modal */}
      <WalletView
        isOpen={isWalletOpen}
        onClose={() => setIsWalletOpen(false)}
        availableBalanceUsd={availableBalanceUsd}
        lockedEscrowUsd={lockedEscrowUsd}
        creditLineAvailableUsd={creditLineAvailableUsd}
        insuranceReservesUsd={insuranceReservesUsd}
        transactions={transactions}
        currency={currency}
        onDeposit={handleDeposit}
        onWithdraw={handleWithdraw}
      />

      {/* Clean Domain-Native Footer (No ornamental telemetry tickers or fake tags) */}
      <footer className="bg-stone-900 border-t border-stone-800 text-stone-400 text-xs py-12 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="space-y-2">
              <span className="text-white font-bold text-base tracking-tight">TerraFin AgriExchange</span>
              <p className="text-stone-400 text-xs leading-relaxed">
                Empowering smallholder cooperatives and global buyers across Africa, India, and Latin America through decentralized escrow, input credit, and parametric satellite insurance.
              </p>
            </div>

            <div>
              <div className="text-stone-200 font-semibold mb-2">East & West Africa</div>
              <ul className="space-y-1 text-stone-400">
                <li>Nairobi ICD · Port of Mombasa · Port of Tema</li>
                <li>Settlement via M-Pesa & NIBSS Instant</li>
                <li>Rainfall Index: CHIRPS 5km Radar</li>
              </ul>
            </div>

            <div>
              <div className="text-stone-200 font-semibold mb-2">India & Bharat Corridor</div>
              <ul className="space-y-1 text-stone-400">
                <li>JNPT Port Navi Mumbai · Ludhiana Silos</li>
                <li>Settlement via UPI 2.0 & e-NAM Escrow</li>
                <li>Index: ISRO Oceansat & IMD Monsoonal Grid</li>
              </ul>
            </div>

            <div>
              <div className="text-stone-200 font-semibold mb-2">Latin America (LATAM)</div>
              <ul className="space-y-1 text-stone-400">
                <li>Port of Santos · Buenaventura · Callao</li>
                <li>Settlement via Pix & SPEI Instant</li>
                <li>Index: MODIS Surface Temp & Landsat-9</li>
              </ul>
            </div>
          </div>

          <div className="pt-8 border-t border-stone-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-stone-400">
            <div>
              © 2026 TerraFin AgriExchange. All smart escrow vaults and parametric indices audited by SGS & PwC Agritech.
            </div>
            <div className="flex items-center gap-4 text-stone-400">
              <span>FairTrade FLO-ID Standard</span>
              <span aria-hidden="true">·</span>
              <span>GlobalGAP Certified</span>
              <span aria-hidden="true">·</span>
              <span>Parametric Resilience Protocol</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
