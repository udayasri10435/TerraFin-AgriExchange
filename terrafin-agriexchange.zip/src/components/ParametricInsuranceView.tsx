import React, { useState } from 'react';
import { ParametricPolicy, ClimateTelemetryData, RegionCorridor, Currency } from '../types';
import { formatCurrency, formatNumber } from '../utils/formatters';
import { SatelliteRadarVisual } from './VisualIllustrations';
import { CloudRain, Sun, AlertTriangle, ShieldCheck, Zap, RefreshCw, Plus, CheckCircle2, X, Activity } from 'lucide-react';

interface ParametricInsuranceViewProps {
  policies: ParametricPolicy[];
  telemetry: Record<string, ClimateTelemetryData>;
  activeCorridor: RegionCorridor;
  currency: Currency;
  onSimulateWeatherAnomaly: (type: 'drought' | 'deluge' | 'reset') => void;
  onTriggerPolicyPayout: (policyId: string) => void;
  onAddNewPolicy: (newPolicy: Omit<ParametricPolicy, 'id' | 'status' | 'payoutAmountUsd' | 'payoutTxHash' | 'payoutTimestamp'>) => void;
  isSimulatingAnomaly: boolean;
  anomalyType: 'drought' | 'deluge' | null;
}

export function ParametricInsuranceView({
  policies,
  telemetry,
  activeCorridor,
  currency,
  onSimulateWeatherAnomaly,
  onTriggerPolicyPayout,
  onAddNewPolicy,
  isSimulatingAnomaly,
  anomalyType,
}: ParametricInsuranceViewProps) {
  const [isPurchaseModalOpen, setIsPurchaseModalOpen] = useState(false);

  // New Policy Form State
  const [formCoop, setFormCoop] = useState('Nakuru Smallholder Cereals Union');
  const [formLocation, setFormLocation] = useState('Subukia Sub-County, Rift Valley');
  const [formCorridor, setFormCorridor] = useState<'africa' | 'india' | 'latam'>('africa');
  const [formCrop, setFormCrop] = useState('High-Yield White Maize');
  const [formHectares, setFormHectares] = useState<number>(40);
  const [formTrigger, setFormTrigger] = useState<'drought_deficit' | 'excess_rainfall_flood' | 'extreme_heat_stress'>('drought_deficit');
  const [formSumInsured, setFormSumInsured] = useState<number>(18000);

  const selectedTelemetryKey = activeCorridor === 'all' ? 'africa' : activeCorridor;
  const currentTelemetry = telemetry[selectedTelemetryKey] || telemetry['africa'];

  const filteredPolicies = policies.filter((p) => {
    if (activeCorridor !== 'all' && p.corridor !== activeCorridor) return false;
    return true;
  });

  const handleCreatePolicySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const premiumRate = 0.045; // 4.5% standard actuarial premium
    const grossPremium = formSumInsured * premiumRate;
    const subsidy = 0.55; // 55% subsidized

    onAddNewPolicy({
      farmerOrCoopName: formCoop,
      parcelLocation: formLocation,
      corridor: formCorridor,
      country: formCorridor === 'africa' ? 'Kenya' : formCorridor === 'india' ? 'India' : 'Brazil',
      cropInsured: formCrop,
      hectares: Number(formHectares),
      triggerType: formTrigger,
      triggerThresholdDescription:
        formTrigger === 'drought_deficit'
          ? 'Seasonal cumulative precipitation < 60mm during 45-day window'
          : formTrigger === 'excess_rainfall_flood'
          ? 'Continuous 72-hour deluge > 180mm during harvest'
          : 'Surface temperature > 38.0°C for 5 consecutive days',
      triggerThresholdValue: formTrigger === 'drought_deficit' ? 60.0 : formTrigger === 'excess_rainfall_flood' ? 180.0 : 5.0,
      currentObservedValue: formTrigger === 'drought_deficit' ? 88.5 : formTrigger === 'excess_rainfall_flood' ? 122.0 : 2.0,
      indexUnit: formTrigger === 'drought_deficit' ? 'mm cumulative rainfall' : formTrigger === 'excess_rainfall_flood' ? 'mm 72h rainfall' : 'days > 38°C',
      sumInsuredUsd: Number(formSumInsured),
      premiumPaidUsd: grossPremium * (1 - subsidy),
      subsidyRatePercent: subsidy * 100,
      policyStart: new Date().toISOString().split('T')[0],
      policyEnd: '2027-01-31',
    });
    setIsPurchaseModalOpen(false);
  };

  return (
    <div className="space-y-8">
      {/* Intro Narrative */}
      <div className="bg-stone-900 text-stone-100 rounded-2xl p-6 sm:p-8 border border-stone-800 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
        <div className="space-y-2 max-w-2xl">
          <div className="text-xs uppercase tracking-widest text-sky-400 font-semibold">
            Satellite Index & Parametric Climate Protection
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            Automated Weather Oracle with Instant Claim Payouts
          </h2>
          <p className="text-xs sm:text-sm text-stone-300 leading-relaxed">
            Eliminates traditional insurance claim disputes and adjusters. Smart policies execute payouts automatically when remote sensing radar (CHIRPS precipitation, Sentinel-2 NDVI, GPM satellite) detects extreme drought or torrential flooding.
          </p>
        </div>

        <button
          onClick={() => setIsPurchaseModalOpen(true)}
          className="px-4 py-2.5 bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer shadow-xs flex items-center gap-2 shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Underwrite New Index Policy</span>
        </button>
      </div>

      {/* Interactive Climate Simulator & Telemetry Radar */}
      <div className="bg-white border border-stone-200 rounded-2xl p-6 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-stone-100 pb-4">
          <div>
            <div className="text-xs text-stone-500 flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5 text-sky-600" />
              <span>Live Remote Sensing District:</span>
              <strong className="text-stone-900">{currentTelemetry.district} ({currentTelemetry.country})</strong>
            </div>
            <p className="text-[11px] text-stone-400 mt-0.5">
              Syncing orbital telemetry from {currentTelemetry.lastSatellitePass}
            </p>
          </div>

          {/* Interactive Simulation Controls */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-semibold text-stone-600 mr-1">Simulate Anomaly:</span>
            <button
              onClick={() => onSimulateWeatherAnomaly('drought')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors cursor-pointer flex items-center gap-1.5 ${
                anomalyType === 'drought'
                  ? 'bg-amber-600 text-white border-amber-600 shadow-xs'
                  : 'bg-amber-50 text-amber-900 border-amber-200 hover:bg-amber-100'
              }`}
            >
              <Sun className="w-3.5 h-3.5 text-amber-500" />
              <span>Severe 60-Day Drought (&lt;45mm)</span>
            </button>

            <button
              onClick={() => onSimulateWeatherAnomaly('deluge')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors cursor-pointer flex items-center gap-1.5 ${
                anomalyType === 'deluge'
                  ? 'bg-rose-600 text-white border-rose-600 shadow-xs'
                  : 'bg-rose-50 text-rose-900 border-rose-200 hover:bg-rose-100'
              }`}
            >
              <CloudRain className="w-3.5 h-3.5 text-rose-500" />
              <span>Monsoon Deluge (&gt;210mm)</span>
            </button>

            {isSimulatingAnomaly && (
              <button
                onClick={() => onSimulateWeatherAnomaly('reset')}
                className="px-3 py-1.5 text-xs font-medium text-stone-600 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                title="Reset simulation to normal weather conditions"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Reset</span>
              </button>
            )}
          </div>
        </div>

        {/* Telemetry Visual Box */}
        <SatelliteRadarVisual
          corridor={selectedTelemetryKey}
          rainfallMm={currentTelemetry.currentSeasonalRainfallMm}
          ndvi={currentTelemetry.currentNdviIndex}
          moisture={currentTelemetry.soilMoisturePercent}
          isTriggered={isSimulatingAnomaly}
        />

        {isSimulatingAnomaly && (
          <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
            <div className="text-xs text-rose-950 space-y-1">
              <div className="font-bold text-sm">
                Satellite Weather Oracle Alert: Parametric Threshold Breached!
              </div>
              <p className="text-rose-900 leading-relaxed">
                The satellite radar verified abnormal {anomalyType === 'drought' ? 'precipitation deficit (38.2mm vs normal 140mm)' : 'continuous deluge (215.0mm vs threshold 180mm)'}. Smart contracts have marked eligible policies for automatic instant claim execution.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Active Policies Portfolio */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold text-stone-900">
            Active Parametric Policies & Live Triggers
          </h3>
          <span className="text-xs text-stone-500 font-mono">
            {filteredPolicies.length} Monitored Parcels
          </span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {filteredPolicies.map((policy) => {
            const isBreached =
              policy.status === 'triggered_paid' ||
              (anomalyType === 'drought' && policy.triggerType === 'drought_deficit') ||
              (anomalyType === 'deluge' && policy.triggerType === 'excess_rainfall_flood');

            return (
              <div
                key={policy.id}
                className={`bg-white border rounded-xl p-5 shadow-xs flex flex-col justify-between transition-all ${
                  isBreached ? 'border-rose-400 ring-2 ring-rose-400/20' : 'border-stone-200'
                }`}
              >
                <div className="space-y-4">
                  {/* Top Policy Metadata */}
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-mono text-stone-500 font-semibold">{policy.id}</span>
                    <span className="font-semibold text-stone-700 uppercase tracking-wider">{policy.country}</span>
                  </div>

                  <div>
                    <h4 className="font-bold text-stone-900 text-base">
                      {policy.farmerOrCoopName}
                    </h4>
                    <p className="text-xs text-stone-500 mt-0.5">
                      {policy.parcelLocation} ({policy.hectares} ha · {policy.cropInsured})
                    </p>
                  </div>

                  {/* Parametric Trigger Definition */}
                  <div className="p-3 bg-stone-50 rounded-lg border border-stone-100 text-xs space-y-1.5">
                    <div className="text-[11px] uppercase tracking-wider text-stone-400 font-semibold">
                      Contract Trigger Mechanism
                    </div>
                    <div className="font-medium text-stone-900">
                      {policy.triggerThresholdDescription}
                    </div>
                    <div className="flex justify-between text-stone-600 pt-1 border-t border-stone-200/60 font-mono text-[11px]">
                      <span>Trigger Threshold:</span>
                      <strong className="text-stone-900">{policy.triggerThresholdValue} {policy.indexUnit}</strong>
                    </div>
                    <div className="flex justify-between text-stone-600 font-mono text-[11px]">
                      <span>Current Satellite Value:</span>
                      <strong className={isBreached ? 'text-rose-600' : 'text-emerald-700'}>
                        {policy.currentObservedValue} {policy.indexUnit}
                      </strong>
                    </div>
                  </div>

                  {/* Financial Coverage Specs */}
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <div className="text-[11px] text-stone-400">Sum Insured</div>
                      <div className="font-mono font-bold text-stone-900 tabular-nums">
                        {formatCurrency(policy.sumInsuredUsd, currency)}
                      </div>
                    </div>
                    <div>
                      <div className="text-[11px] text-stone-400">Govt. Climate Subsidy</div>
                      <div className="font-mono font-bold text-emerald-700 tabular-nums">
                        {policy.subsidyRatePercent}% subsidized
                      </div>
                    </div>
                  </div>
                </div>

                {/* Bottom Action / Status */}
                <div className="pt-4 mt-4 border-t border-stone-100 flex items-center justify-between gap-2">
                  {policy.status === 'triggered_paid' ? (
                    <div className="text-xs text-emerald-800 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200 font-medium flex items-center gap-1.5 w-full justify-center">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>Claim Settled: {formatCurrency(policy.payoutAmountUsd || policy.sumInsuredUsd, currency)}</span>
                    </div>
                  ) : isBreached ? (
                    <button
                      onClick={() => onTriggerPolicyPayout(policy.id)}
                      className="w-full py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer shadow-xs flex items-center justify-center gap-1.5 animate-pulse"
                    >
                      <Zap className="w-3.5 h-3.5" />
                      <span>Execute Satellite Claim Payout</span>
                    </button>
                  ) : (
                    <div className="text-xs text-stone-500 flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4 text-emerald-600" />
                      <span>Satellite Oracle Nominal · No Breach</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Underwrite Policy Modal */}
      {isPurchaseModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full border border-stone-200 shadow-2xl overflow-hidden">
            <div className="px-6 py-4 border-b border-stone-200 flex items-center justify-between bg-stone-50">
              <h3 className="font-bold text-base text-stone-900">
                Underwrite Parametric Weather Index Policy
              </h3>
              <button
                onClick={() => setIsPurchaseModalOpen(false)}
                className="text-stone-400 hover:text-stone-700 p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreatePolicySubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Farmer Cooperative / Group Name *
                </label>
                <input
                  type="text"
                  required
                  value={formCoop}
                  onChange={(e) => setFormCoop(e.target.value)}
                  className="w-full text-xs p-2.5 border border-stone-200 rounded-lg focus:ring-2 focus:ring-sky-600/20"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Operating Corridor *
                  </label>
                  <select
                    value={formCorridor}
                    onChange={(e) => setFormCorridor(e.target.value as 'africa' | 'india' | 'latam')}
                    className="w-full text-xs p-2.5 border border-stone-200 rounded-lg"
                  >
                    <option value="africa">Africa (Kenya/Nigeria)</option>
                    <option value="india">India (Punjab/Vidarbha)</option>
                    <option value="latam">LATAM (Brazil/Colombia)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Insured Crop *
                  </label>
                  <input
                    type="text"
                    required
                    value={formCrop}
                    onChange={(e) => setFormCrop(e.target.value)}
                    className="w-full text-xs p-2.5 border border-stone-200 rounded-lg"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Parcel GPS Location / District *
                </label>
                <input
                  type="text"
                  required
                  value={formLocation}
                  onChange={(e) => setFormLocation(e.target.value)}
                  className="w-full text-xs p-2.5 border border-stone-200 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Parametric Trigger Metric *
                </label>
                <select
                  value={formTrigger}
                  onChange={(e) => setFormTrigger(e.target.value as any)}
                  className="w-full text-xs p-2.5 border border-stone-200 rounded-lg"
                >
                  <option value="drought_deficit">CHIRPS Severe Drought Deficit (&lt;60mm cumulative)</option>
                  <option value="excess_rainfall_flood">GPM Satellite Torrential Deluge (&gt;180mm / 72h)</option>
                  <option value="extreme_heat_stress">MODIS Heat Stress (&gt;38°C for 5 consecutive days)</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Hectares Insured *
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={formHectares}
                    onChange={(e) => setFormHectares(Number(e.target.value))}
                    className="w-full text-xs p-2.5 border border-stone-200 rounded-lg font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Total Sum Insured (USD) *
                  </label>
                  <input
                    type="number"
                    min={1000}
                    step={500}
                    value={formSumInsured}
                    onChange={(e) => setFormSumInsured(Number(e.target.value))}
                    className="w-full text-xs p-2.5 border border-stone-200 rounded-lg font-mono"
                  />
                </div>
              </div>

              {/* Subsidized Premium Breakdown */}
              <div className="p-3 bg-sky-50 rounded-xl border border-sky-100 text-xs space-y-1">
                <div className="flex justify-between text-stone-700">
                  <span>Gross Actuarial Premium (4.5%):</span>
                  <span className="font-mono tabular-nums">${formatNumber(formSumInsured * 0.045)} USD</span>
                </div>
                <div className="flex justify-between text-emerald-800 font-medium">
                  <span>Climate Facility Subsidy (55%):</span>
                  <span className="font-mono tabular-nums">-${formatNumber(formSumInsured * 0.045 * 0.55)} USD</span>
                </div>
                <div className="flex justify-between font-bold text-stone-900 border-t border-sky-200 pt-1">
                  <span>Farmer Cooperative Net Premium:</span>
                  <span className="font-mono tabular-nums text-sky-800">
                    {formatCurrency(formSumInsured * 0.045 * 0.45, currency)}
                  </span>
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-3 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setIsPurchaseModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-stone-600 hover:text-stone-900 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer shadow-xs"
                >
                  Activate Satellite Policy
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
