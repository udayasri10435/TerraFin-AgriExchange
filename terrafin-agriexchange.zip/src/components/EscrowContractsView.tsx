import React from 'react';
import { EscrowContract, Currency } from '../types';
import { formatCurrency, formatNumber } from '../utils/formatters';
import { ShieldCheck, Truck, CheckCircle2, ArrowRight, Clock, FileCheck, DollarSign } from 'lucide-react';

interface EscrowContractsViewProps {
  contracts: EscrowContract[];
  currency: Currency;
  onAdvanceContract: (contractId: string) => void;
  onReleaseFunds: (contractId: string) => void;
}

export function EscrowContractsView({
  contracts,
  currency,
  onAdvanceContract,
  onReleaseFunds,
}: EscrowContractsViewProps) {
  return (
    <div className="space-y-8">
      {/* Intro Context Banner */}
      <div className="bg-stone-900 text-stone-100 rounded-2xl p-6 sm:p-8 border border-stone-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2 max-w-2xl">
          <div className="text-xs uppercase tracking-widest text-emerald-400 font-semibold">
            Trustless Settlement Protocol
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            Smart Escrow Vaults & Multi-Stage Crop Inspection
          </h2>
          <p className="text-xs sm:text-sm text-stone-300 leading-relaxed">
            Eliminates counterparty default for cross-border African, Indian, and Latin American agricultural trade. Buyer funds remain securely locked until third-party SGS or cooperative depot tests verify moisture, weight, and grade.
          </p>
        </div>

        <div className="bg-stone-800/80 rounded-xl p-4 border border-stone-700/60 shrink-0 text-right">
          <div className="text-[11px] text-stone-400 font-medium">Active Escrow Value</div>
          <div className="text-2xl font-bold text-emerald-400 font-mono tabular-nums">
            {formatCurrency(
              contracts
                .filter((c) => c.escrowStatus !== 'disbursed_to_farmer')
                .reduce((acc, c) => acc + c.totalAmountUsd, 0),
              currency
            )}
          </div>
          <div className="text-[11px] text-stone-400 mt-1">
            Across {contracts.filter((c) => c.escrowStatus !== 'disbursed_to_farmer').length} active shipments
          </div>
        </div>
      </div>

      {/* Contracts List */}
      <div className="space-y-6">
        {contracts.map((contract) => {
          const isDepositLocked = contract.escrowStatus === 'deposit_locked';
          const isInTransit = contract.escrowStatus === 'in_transit';
          const isInspected = contract.escrowStatus === 'quality_inspected';
          const isDisbursed = contract.escrowStatus === 'disbursed_to_farmer';

          return (
            <div
              key={contract.id}
              className="bg-white border border-stone-200 rounded-xl p-6 shadow-xs space-y-6 hover:border-stone-300 transition-colors"
            >
              {/* Header Bar */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-stone-100 pb-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-xs text-stone-500">
                    <span className="font-mono font-semibold text-stone-900">{contract.id}</span>
                    <span aria-hidden="true">·</span>
                    <span>Deposit: {contract.depositTimestamp}</span>
                    <span aria-hidden="true">·</span>
                    <span>Inspection Window: {contract.inspectionWindowHours}h</span>
                  </div>
                  <h3 className="text-lg font-bold text-stone-900">
                    {contract.cropName}
                  </h3>
                </div>

                <div className="text-left sm:text-right">
                  <div className="text-[11px] text-stone-400 uppercase tracking-wider">Contract Total</div>
                  <div className="text-xl font-bold font-mono tabular-nums text-stone-900">
                    {formatCurrency(contract.totalAmountUsd, currency)}
                  </div>
                  {currency !== 'USD' && (
                    <div className="text-[11px] text-stone-400 font-mono tabular-nums">
                      ${formatNumber(contract.totalAmountUsd)} USD
                    </div>
                  )}
                </div>
              </div>

              {/* Milestones Flow (Clean unboxed timeline) */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 pt-1">
                {/* Stage 1 */}
                <div className={`p-3 rounded-lg border text-xs ${
                  isDepositLocked || isInTransit || isInspected || isDisbursed
                    ? 'bg-emerald-50/70 border-emerald-200 text-emerald-900'
                    : 'bg-stone-50 border-stone-200 text-stone-400'
                }`}>
                  <div className="flex items-center justify-between mb-1 font-semibold">
                    <span>1. Deposit Locked</span>
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  </div>
                  <p className="text-[11px] text-emerald-800/80">
                    Buyer earnest funds secured in smart escrow vault.
                  </p>
                </div>

                {/* Stage 2 */}
                <div className={`p-3 rounded-lg border text-xs ${
                  isInTransit || isInspected || isDisbursed
                    ? 'bg-emerald-50/70 border-emerald-200 text-emerald-900'
                    : isDepositLocked
                    ? 'bg-amber-50/70 border-amber-200 text-amber-900'
                    : 'bg-stone-50 border-stone-200 text-stone-400'
                }`}>
                  <div className="flex items-center justify-between mb-1 font-semibold">
                    <span>2. Freight Logistics</span>
                    {isInTransit || isInspected || isDisbursed ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    ) : (
                      <Clock className="w-4 h-4 text-amber-600" />
                    )}
                  </div>
                  <p className="text-[11px] text-stone-600">
                    Tracking: <span className="font-mono">{contract.trackingNumber}</span>
                  </p>
                </div>

                {/* Stage 3 */}
                <div className={`p-3 rounded-lg border text-xs ${
                  isInspected || isDisbursed
                    ? 'bg-emerald-50/70 border-emerald-200 text-emerald-900'
                    : isInTransit
                    ? 'bg-amber-50/70 border-amber-200 text-amber-900'
                    : 'bg-stone-50 border-stone-200 text-stone-400'
                }`}>
                  <div className="flex items-center justify-between mb-1 font-semibold">
                    <span>3. Quality Inspection</span>
                    {isInspected || isDisbursed ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    ) : (
                      <FileCheck className="w-4 h-4 text-stone-400" />
                    )}
                  </div>
                  <p className="text-[11px] text-stone-600">
                    Moisture: <span className="font-mono font-medium">{contract.moistureVerifiedPercent}%</span> verified.
                  </p>
                </div>

                {/* Stage 4 */}
                <div className={`p-3 rounded-lg border text-xs ${
                  isDisbursed
                    ? 'bg-emerald-50/70 border-emerald-200 text-emerald-900'
                    : 'bg-stone-50 border-stone-200 text-stone-400'
                }`}>
                  <div className="flex items-center justify-between mb-1 font-semibold">
                    <span>4. Farmer Payout</span>
                    {isDisbursed ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    ) : (
                      <DollarSign className="w-4 h-4 text-stone-400" />
                    )}
                  </div>
                  <p className="text-[11px] text-stone-600">
                    {isDisbursed ? 'Disbursed to coop account' : 'Awaiting buyer signoff'}
                  </p>
                </div>
              </div>

              {/* Detailed Parties & Log Info */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs bg-stone-50 p-4 rounded-xl border border-stone-100">
                <div>
                  <div className="text-stone-400 text-[11px] uppercase tracking-wider">Buyer Entity</div>
                  <div className="font-semibold text-stone-900 mt-0.5">{contract.buyerName}</div>
                </div>
                <div>
                  <div className="text-stone-400 text-[11px] uppercase tracking-wider">Farmer Cooperative</div>
                  <div className="font-semibold text-stone-900 mt-0.5">{contract.cooperativeName}</div>
                  <div className="text-stone-500 text-[11px]">{contract.farmerName}</div>
                </div>
                <div>
                  <div className="text-stone-400 text-[11px] uppercase tracking-wider">Freight & Carrier</div>
                  <div className="font-semibold text-stone-900 mt-0.5">{contract.logisticsProvider}</div>
                  <div className="text-stone-500 text-[11px]">{contract.notes}</div>
                </div>
              </div>

              {/* Interactive Actions */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                <div className="text-xs text-stone-500 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-700" />
                  <span>SGS Third-Party Quality Guarantee Active</span>
                </div>

                <div className="flex items-center gap-3">
                  {isInTransit && (
                    <button
                      onClick={() => onAdvanceContract(contract.id)}
                      className="px-4 py-2 bg-stone-800 hover:bg-stone-700 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer flex items-center gap-1.5"
                    >
                      <FileCheck className="w-3.5 h-3.5" />
                      <span>Log Port Arrival & SGS Lab Test</span>
                    </button>
                  )}

                  {isInspected && (
                    <button
                      onClick={() => onReleaseFunds(contract.id)}
                      className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer shadow-xs flex items-center gap-1.5"
                    >
                      <DollarSign className="w-3.5 h-3.5" />
                      <span>Authorize Payout to Farmer Wallet</span>
                    </button>
                  )}

                  {isDisbursed && (
                    <span className="text-xs font-semibold text-emerald-800 flex items-center gap-1 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" />
                      <span>Completed & Settled ({contract.disbursedTimestamp || 'Instant'})</span>
                    </span>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
