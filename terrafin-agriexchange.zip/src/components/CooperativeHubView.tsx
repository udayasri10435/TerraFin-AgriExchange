import React from 'react';
import { CooperativeProfile, RegionCorridor } from '../types';
import { formatNumber } from '../utils/formatters';
import { Building2, Award, Users, MapPin, CheckCircle, ExternalLink, Shield } from 'lucide-react';

interface CooperativeHubViewProps {
  cooperatives: CooperativeProfile[];
  activeCorridor: RegionCorridor;
  onFilterByCooperative?: (coopName: string) => void;
}

export function CooperativeHubView({
  cooperatives,
  activeCorridor,
  onFilterByCooperative,
}: CooperativeHubViewProps) {
  const filteredCoops = cooperatives.filter((c) => {
    if (activeCorridor !== 'all' && c.corridor !== activeCorridor) return false;
    return true;
  });

  return (
    <div className="space-y-8">
      {/* Intro Narrative */}
      <div className="bg-stone-900 text-stone-100 rounded-2xl p-6 sm:p-8 border border-stone-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2 max-w-2xl">
          <div className="text-xs uppercase tracking-widest text-emerald-400 font-semibold">
            Traceability & Smallholder Governance
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            Verified Farmer Cooperatives & Producer Unions
          </h2>
          <p className="text-xs sm:text-sm text-stone-300 leading-relaxed">
            Every listing, input financing package, and parametric policy is anchored to legally incorporated, audited farmer cooperatives across Africa, India, and Latin America. Trace every gram of produce back to registered member acreage.
          </p>
        </div>

        <div className="bg-stone-800/80 rounded-xl p-4 border border-stone-700/60 shrink-0 text-right">
          <div className="text-[11px] text-stone-400">Total Registered Smallholders</div>
          <div className="text-2xl font-bold text-white font-mono tabular-nums">
            {formatNumber(cooperatives.reduce((acc, c) => acc + c.activeFarmersCount, 0))}
          </div>
          <div className="text-[11px] text-emerald-400 mt-1">100% KYC & GPS Verified</div>
        </div>
      </div>

      {/* Cooperatives Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredCoops.map((coop) => (
          <div
            key={coop.id}
            className="bg-white border border-stone-200 rounded-xl p-6 shadow-xs space-y-5 hover:border-stone-300 transition-colors flex flex-col justify-between"
          >
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs">
                <span className="font-mono text-stone-500 font-semibold">{coop.id}</span>
                <span className="font-semibold text-stone-700 uppercase tracking-wider">{coop.country}</span>
              </div>

              <div>
                <h3 className="text-lg font-bold text-stone-900">
                  {coop.name}
                </h3>
                <div className="flex items-center gap-1.5 text-xs text-stone-500 mt-1">
                  <MapPin className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                  <span>{coop.region} (Est. {coop.yearEstablished})</span>
                </div>
              </div>

              {/* Quantitative Metrics Grid */}
              <div className="grid grid-cols-3 gap-3 bg-stone-50 p-3 rounded-lg border border-stone-100 text-xs">
                <div>
                  <div className="text-[11px] text-stone-400">Active Farmers</div>
                  <div className="font-bold text-stone-900 font-mono tabular-nums mt-0.5">
                    {formatNumber(coop.activeFarmersCount)}
                  </div>
                </div>
                <div>
                  <div className="text-[11px] text-stone-400">Total Land</div>
                  <div className="font-bold text-stone-900 font-mono tabular-nums mt-0.5">
                    {formatNumber(coop.totalHectares)} ha
                  </div>
                </div>
                <div>
                  <div className="text-[11px] text-stone-400">Annual Export</div>
                  <div className="font-bold text-stone-900 font-mono tabular-nums mt-0.5">
                    {formatNumber(coop.annualTonnageExported)} MT
                  </div>
                </div>
              </div>

              {/* Crops & Certifications (Clean unboxed text) */}
              <div className="space-y-1.5 text-xs">
                <div className="text-stone-500 flex items-center gap-1.5">
                  <strong className="text-stone-700">Primary Crops:</strong>
                  <span>{coop.primaryCrops.join(' · ')}</span>
                </div>
                <div className="text-stone-500 flex items-center gap-1.5">
                  <strong className="text-stone-700">Certifications:</strong>
                  <span>{coop.certifications.join(' · ')}</span>
                </div>
              </div>
            </div>

            {/* Bottom Audit Rating & Contact */}
            <div className="pt-4 border-t border-stone-100 flex items-center justify-between text-xs">
              <div className="flex items-center gap-1.5 text-emerald-800">
                <Shield className="w-4 h-4 text-emerald-600" />
                <span className="font-medium">{coop.auditRating}</span>
              </div>

              <div className="text-stone-500 text-[11px]">
                GM: {coop.contactPerson}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
