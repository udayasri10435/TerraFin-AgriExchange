import React from 'react';
import { Currency, RegionCorridor } from '../types';
import { formatCurrency } from '../utils/formatters';
import { Wallet, Globe, ArrowUpRight } from 'lucide-react';

interface HeaderProps {
  activeTab: 'marketplace' | 'escrow' | 'financing' | 'insurance' | 'cooperatives' | 'wallet';
  setActiveTab: (tab: 'marketplace' | 'escrow' | 'financing' | 'insurance' | 'cooperatives' | 'wallet') => void;
  activeCorridor: RegionCorridor;
  setActiveCorridor: (corridor: RegionCorridor) => void;
  currency: Currency;
  setCurrency: (c: Currency) => void;
  walletBalanceUsd: number;
  onOpenWallet: () => void;
  onOpenNewListing: () => void;
}

export function Header({
  activeTab,
  setActiveTab,
  activeCorridor,
  setActiveCorridor,
  currency,
  setCurrency,
  walletBalanceUsd,
  onOpenWallet,
  onOpenNewListing,
}: HeaderProps) {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Zone 1: Single text element Brand Zone */}
        <button
          onClick={() => setActiveTab('marketplace')}
          className="text-left font-bold tracking-tight text-xl text-stone-900 hover:text-emerald-800 transition-colors cursor-pointer shrink-0"
        >
          TerraFin AgriExchange
        </button>

        {/* Zone 2: 4-6 clean text navigation links */}
        <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-stone-600">
          <button
            onClick={() => setActiveTab('marketplace')}
            className={`transition-colors cursor-pointer ${
              activeTab === 'marketplace'
                ? 'text-stone-950 font-semibold underline underline-offset-8 decoration-emerald-600 decoration-2'
                : 'hover:text-stone-950'
            }`}
          >
            Marketplace
          </button>
          <button
            onClick={() => setActiveTab('escrow')}
            className={`transition-colors cursor-pointer ${
              activeTab === 'escrow'
                ? 'text-stone-950 font-semibold underline underline-offset-8 decoration-emerald-600 decoration-2'
                : 'hover:text-stone-950'
            }`}
          >
            Escrow Contracts
          </button>
          <button
            onClick={() => setActiveTab('financing')}
            className={`transition-colors cursor-pointer ${
              activeTab === 'financing'
                ? 'text-stone-950 font-semibold underline underline-offset-8 decoration-emerald-600 decoration-2'
                : 'hover:text-stone-950'
            }`}
          >
            Input Financing
          </button>
          <button
            onClick={() => setActiveTab('insurance')}
            className={`transition-colors cursor-pointer ${
              activeTab === 'insurance'
                ? 'text-stone-950 font-semibold underline underline-offset-8 decoration-emerald-600 decoration-2'
                : 'hover:text-stone-950'
            }`}
          >
            Crop Insurance
          </button>
          <button
            onClick={() => setActiveTab('cooperatives')}
            className={`transition-colors cursor-pointer ${
              activeTab === 'cooperatives'
                ? 'text-stone-950 font-semibold underline underline-offset-8 decoration-emerald-600 decoration-2'
                : 'hover:text-stone-950'
            }`}
          >
            Cooperatives
          </button>
        </nav>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-3">
          {/* Quick Currency Selector */}
          <div className="flex items-center text-xs border border-stone-200 rounded-lg p-0.5 bg-stone-50">
            {(['USD', 'KES', 'INR', 'BRL'] as Currency[]).map((cur) => (
              <button
                key={cur}
                onClick={() => setCurrency(cur)}
                className={`px-2 py-1 rounded text-xs font-mono transition-colors cursor-pointer ${
                  currency === cur
                    ? 'bg-white text-stone-900 font-semibold shadow-xs'
                    : 'text-stone-500 hover:text-stone-800'
                }`}
              >
                {cur}
              </button>
            ))}
          </div>

          {/* Wallet Trigger Button */}
          <button
            onClick={onOpenWallet}
            className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-medium text-stone-800 bg-stone-100 hover:bg-stone-200 border border-stone-200 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
            title="Open Settlement Wallet"
          >
            <Wallet className="w-3.5 h-3.5 text-emerald-700" />
            <span className="font-mono tabular-nums font-semibold">
              {formatCurrency(walletBalanceUsd, currency)}
            </span>
          </button>

          {/* Primary Action Button */}
          <button
            onClick={onOpenNewListing}
            className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg transition-colors cursor-pointer shadow-xs whitespace-nowrap"
          >
            <span>List Harvest</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Mobile Secondary Navigation Row (only on small viewports) */}
      <div className="lg:hidden flex items-center justify-between border-t border-stone-200 px-4 py-2 overflow-x-auto gap-4 text-xs font-medium text-stone-600">
        <button
          onClick={() => setActiveTab('marketplace')}
          className={`shrink-0 ${activeTab === 'marketplace' ? 'text-emerald-700 font-bold' : ''}`}
        >
          Marketplace
        </button>
        <button
          onClick={() => setActiveTab('escrow')}
          className={`shrink-0 ${activeTab === 'escrow' ? 'text-emerald-700 font-bold' : ''}`}
        >
          Escrow Contracts
        </button>
        <button
          onClick={() => setActiveTab('financing')}
          className={`shrink-0 ${activeTab === 'financing' ? 'text-emerald-700 font-bold' : ''}`}
        >
          Input Financing
        </button>
        <button
          onClick={() => setActiveTab('insurance')}
          className={`shrink-0 ${activeTab === 'insurance' ? 'text-emerald-700 font-bold' : ''}`}
        >
          Crop Insurance
        </button>
        <button
          onClick={() => setActiveTab('cooperatives')}
          className={`shrink-0 ${activeTab === 'cooperatives' ? 'text-emerald-700 font-bold' : ''}`}
        >
          Cooperatives
        </button>
      </div>
    </header>
  );
}
