import React from 'react';
import { RegionCorridor, Currency } from '../types';
import { CORRIDOR_DETAILS, formatCurrency, formatNumber } from '../utils/formatters';
import { Globe, ShieldCheck, Sprout, CloudRain, ArrowRight } from 'lucide-react';

interface HeroOverviewProps {
  activeCorridor: RegionCorridor;
  setActiveCorridor: (corridor: RegionCorridor) => void;
  currency: Currency;
  onExploreTab: (tab: 'marketplace' | 'financing' | 'insurance') => void;
}

export function HeroOverview({
  activeCorridor,
  setActiveCorridor,
  currency,
  onExploreTab,
}: HeroOverviewProps) {
  const currentCorridorInfo = CORRIDOR_DETAILS[activeCorridor];

  return (
    <div className="bg-stone-900 text-stone-100 border-b border-stone-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 lg:py-12">
        {/* Corridor Segmented Controls */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
          <div className="flex items-center gap-1.5 p-1 bg-stone-800/90 rounded-xl border border-stone-700/60 overflow-x-auto max-w-full">
            <button
              onClick={() => setActiveCorridor('all')}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                activeCorridor === 'all'
                  ? 'bg-emerald-600 text-white shadow-xs font-semibold'
                  : 'text-stone-300 hover:text-white'
              }`}
            >
              All Corridors (Global)
            </button>
            <button
              onClick={() => setActiveCorridor('africa')}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                activeCorridor === 'africa'
                  ? 'bg-emerald-600 text-white shadow-xs font-semibold'
                  : 'text-stone-300 hover:text-white'
              }`}
            >
              East & West Africa (KES/NGN)
            </button>
            <button
              onClick={() => setActiveCorridor('india')}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                activeCorridor === 'india'
                  ? 'bg-emerald-600 text-white shadow-xs font-semibold'
                  : 'text-stone-300 hover:text-white'
              }`}
            >
              India & Bharat (INR ₹)
            </button>
            <button
              onClick={() => setActiveCorridor('latam')}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                activeCorridor === 'latam'
                  ? 'bg-emerald-600 text-white shadow-xs font-semibold'
                  : 'text-stone-300 hover:text-white'
              }`}
            >
              Latin America (BRL/COP)
            </button>
          </div>

          {/* Regional Context text */}
          <div className="text-xs text-stone-400 flex items-center gap-2">
            <span>Operating Corridors</span>
            <span aria-hidden="true">·</span>
            <span className="text-stone-300 font-medium">{currentCorridorInfo.countries}</span>
          </div>
        </div>

        {/* Hero Narrative Split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-7 space-y-4">
            <div className="text-xs uppercase tracking-widest text-emerald-400 font-semibold">
              Cross-Border Agritech & Sovereign Settlement
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-white max-w-2xl leading-[1.15]" style={{ textWrap: 'balance' }}>
              Decentralized commodity exchange, input credit & parametric risk transfer.
            </h1>

            <p className="text-stone-300 text-base max-w-xl leading-relaxed">
              Empowering smallholder cooperatives across Africa, India, and Latin America. Directly connect farm harvests to global buyers via smart contract escrow, finance inputs without land titles, and safeguard crop yield with automated satellite weather indices.
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={() => onExploreTab('marketplace')}
                className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer flex items-center gap-2 shadow-sm"
              >
                <span>Browse Produce Catalog</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => onExploreTab('insurance')}
                className="px-4 py-2.5 bg-stone-800 hover:bg-stone-700 text-stone-200 border border-stone-700 text-xs font-semibold rounded-lg transition-colors cursor-pointer flex items-center gap-2"
              >
                <CloudRain className="w-3.5 h-3.5 text-sky-400" />
                <span>Test Satellite Weather Oracle</span>
              </button>
            </div>
          </div>

          {/* Quantitative Proof Grid */}
          <div className="lg:col-span-5 grid grid-cols-2 gap-4">
            <div className="bg-stone-800/70 border border-stone-700/60 rounded-xl p-4">
              <div className="text-[11px] text-stone-400 font-medium mb-1">Total Escrow Volume</div>
              <div className="text-2xl font-bold text-white font-mono tabular-nums">
                {formatCurrency(14850000, currency)}
              </div>
              <div className="text-xs text-emerald-400 mt-2 flex items-center gap-1">
                <span>100% on-time settlement</span>
              </div>
            </div>

            <div className="bg-stone-800/70 border border-stone-700/60 rounded-xl p-4">
              <div className="text-[11px] text-stone-400 font-medium mb-1">Smallholder Hectares</div>
              <div className="text-2xl font-bold text-white font-mono tabular-nums">
                {formatNumber(124800)} <span className="text-sm font-normal text-stone-400">ha</span>
              </div>
              <div className="text-xs text-stone-400 mt-2">
                Across 32 registered co-ops
              </div>
            </div>

            <div className="bg-stone-800/70 border border-stone-700/60 rounded-xl p-4">
              <div className="text-[11px] text-stone-400 font-medium mb-1">Input Credit Disbursed</div>
              <div className="text-2xl font-bold text-white font-mono tabular-nums">
                {formatCurrency(4620000, currency)}
              </div>
              <div className="text-xs text-emerald-400 mt-2">
                98.8% harvest recovery rate
              </div>
            </div>

            <div className="bg-stone-800/70 border border-stone-700/60 rounded-xl p-4">
              <div className="text-[11px] text-stone-400 font-medium mb-1">Satellite Claim Oracle</div>
              <div className="text-2xl font-bold text-sky-400 font-mono tabular-nums">
                &lt; 60 sec
              </div>
              <div className="text-xs text-stone-400 mt-2">
                Zero adjuster paperwork delay
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
