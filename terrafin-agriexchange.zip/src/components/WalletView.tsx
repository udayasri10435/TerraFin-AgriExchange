import React, { useState } from 'react';
import { WalletTransaction, Currency } from '../types';
import { formatCurrency, formatNumber } from '../utils/formatters';
import { Wallet, ArrowDownLeft, ArrowUpRight, ShieldCheck, CheckCircle2, X, RefreshCw } from 'lucide-react';

interface WalletViewProps {
  isOpen: boolean;
  onClose: () => void;
  availableBalanceUsd: number;
  lockedEscrowUsd: number;
  creditLineAvailableUsd: number;
  insuranceReservesUsd: number;
  transactions: WalletTransaction[];
  currency: Currency;
  onDeposit: (amountUsd: number, rail: string) => void;
  onWithdraw: (amountUsd: number, destination: string) => void;
}

export function WalletView({
  isOpen,
  onClose,
  availableBalanceUsd,
  lockedEscrowUsd,
  creditLineAvailableUsd,
  insuranceReservesUsd,
  transactions,
  currency,
  onDeposit,
  onWithdraw,
}: WalletViewProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'deposit' | 'withdraw'>('overview');
  const [depositAmount, setDepositAmount] = useState<number>(10000);
  const [depositRail, setDepositRail] = useState<string>('M-Pesa B2B Kenya');
  const [withdrawAmount, setWithdrawAmount] = useState<number>(5000);
  const [withdrawDestination, setWithdrawDestination] = useState<string>('Cooperative Central Bancolombia');
  const [actionNotice, setActionNotice] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleDepositSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onDeposit(depositAmount, depositRail);
    setActionNotice(`Successfully deposited ${formatCurrency(depositAmount, currency)} via ${depositRail}`);
    setActiveTab('overview');
    setTimeout(() => setActionNotice(null), 4000);
  };

  const handleWithdrawSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (withdrawAmount > availableBalanceUsd) {
      alert('Withdrawal amount exceeds available balance.');
      return;
    }
    onWithdraw(withdrawAmount, withdrawDestination);
    setActionNotice(`Successfully transferred ${formatCurrency(withdrawAmount, currency)} to ${withdrawDestination}`);
    setActiveTab('overview');
    setTimeout(() => setActionNotice(null), 4000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/65 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-2xl w-full border border-stone-200 shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        {/* Top Header */}
        <div className="px-6 py-4 border-b border-stone-200 flex items-center justify-between bg-stone-50 shrink-0">
          <div className="flex items-center gap-2">
            <Wallet className="w-5 h-5 text-emerald-700" />
            <h3 className="font-bold text-base text-stone-900">
              Cross-Border Settlement Treasury & Wallet
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-stone-400 hover:text-stone-700 p-1 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Controls */}
        <div className="flex items-center gap-2 px-6 pt-4 border-b border-stone-100 shrink-0 text-xs">
          <button
            onClick={() => setActiveTab('overview')}
            className={`pb-2 font-semibold cursor-pointer border-b-2 transition-colors ${
              activeTab === 'overview'
                ? 'border-emerald-700 text-emerald-800'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            Treasury Balances
          </button>
          <button
            onClick={() => setActiveTab('deposit')}
            className={`pb-2 font-semibold cursor-pointer border-b-2 transition-colors ${
              activeTab === 'deposit'
                ? 'border-emerald-700 text-emerald-800'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            Top-Up / Deposit
          </button>
          <button
            onClick={() => setActiveTab('withdraw')}
            className={`pb-2 font-semibold cursor-pointer border-b-2 transition-colors ${
              activeTab === 'withdraw'
                ? 'border-emerald-700 text-emerald-800'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            Withdraw / Instant Rail
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6 overflow-y-auto space-y-6">
          {actionNotice && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-900 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{actionNotice}</span>
            </div>
          )}

          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Balances Grid */}
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-stone-900 text-white rounded-xl p-4">
                  <div className="text-[11px] text-stone-400 uppercase tracking-wider">Available Cash</div>
                  <div className="text-2xl font-bold font-mono tabular-nums text-emerald-400 mt-1">
                    {formatCurrency(availableBalanceUsd, currency)}
                  </div>
                  <div className="text-[10px] text-stone-400 mt-1">
                    Ready for escrow purchase or withdrawal
                  </div>
                </div>

                <div className="bg-stone-50 rounded-xl p-4 border border-stone-200">
                  <div className="text-[11px] text-stone-500 uppercase tracking-wider">Locked in Escrow</div>
                  <div className="text-2xl font-bold font-mono tabular-nums text-stone-900 mt-1">
                    {formatCurrency(lockedEscrowUsd, currency)}
                  </div>
                  <div className="text-[10px] text-stone-400 mt-1">
                    Held safely until cargo inspection release
                  </div>
                </div>

                <div className="bg-stone-50 rounded-xl p-4 border border-stone-200">
                  <div className="text-[11px] text-stone-500 uppercase tracking-wider">Input Credit Line</div>
                  <div className="text-2xl font-bold font-mono tabular-nums text-stone-900 mt-1">
                    {formatCurrency(creditLineAvailableUsd, currency)}
                  </div>
                  <div className="text-[10px] text-stone-400 mt-1">
                    Pre-approved seed & fertilizer limit
                  </div>
                </div>

                <div className="bg-stone-50 rounded-xl p-4 border border-stone-200">
                  <div className="text-[11px] text-stone-500 uppercase tracking-wider">Insurance Payout Reserves</div>
                  <div className="text-2xl font-bold font-mono tabular-nums text-sky-700 mt-1">
                    {formatCurrency(insuranceReservesUsd, currency)}
                  </div>
                  <div className="text-[10px] text-stone-400 mt-1">
                    Satellite parametric claim disbursements
                  </div>
                </div>
              </div>

              {/* Transactions Ledger */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-stone-900 text-sm">
                    Recent Treasury Ledger Entries
                  </h4>
                  <span className="text-xs text-stone-500 font-mono">
                    {transactions.length} Transactions
                  </span>
                </div>

                <div className="border border-stone-200 rounded-xl overflow-hidden divide-y divide-stone-100 text-xs">
                  {transactions.map((txn) => {
                    const isPositive = txn.amountUsd > 0;
                    return (
                      <div key={txn.id} className="p-3.5 flex items-center justify-between gap-4 hover:bg-stone-50/60">
                        <div className="space-y-0.5 max-w-[360px]">
                          <div className="font-medium text-stone-900 truncate">
                            {txn.description}
                          </div>
                          <div className="text-[11px] text-stone-400 flex items-center gap-1.5 font-mono">
                            <span>{txn.timestamp}</span>
                            <span aria-hidden="true">·</span>
                            <span>{txn.rail}</span>
                            <span aria-hidden="true">·</span>
                            <span>{txn.referenceId}</span>
                          </div>
                        </div>

                        <div className="text-right shrink-0">
                          <div className={`font-mono font-bold tabular-nums ${
                            isPositive ? 'text-emerald-700' : 'text-stone-900'
                          }`}>
                            {isPositive ? '+' : ''}{formatCurrency(txn.amountUsd, currency)}
                          </div>
                          <span className="text-[10px] text-emerald-800 uppercase font-semibold">
                            {txn.status}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'deposit' && (
            <form onSubmit={handleDepositSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Deposit Amount (USD) *
                </label>
                <input
                  type="number"
                  min={100}
                  step={100}
                  value={depositAmount}
                  onChange={(e) => setDepositAmount(Number(e.target.value))}
                  className="w-full text-sm font-mono p-3 border border-stone-200 rounded-xl focus:ring-2 focus:ring-emerald-600/20"
                />
                <div className="text-[11px] text-stone-500 mt-1 font-mono">
                  Equivalent: {formatCurrency(depositAmount, currency)}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Select Regional Rail
                </label>
                <select
                  value={depositRail}
                  onChange={(e) => setDepositRail(e.target.value)}
                  className="w-full text-xs p-3 border border-stone-200 rounded-xl"
                >
                  <option value="M-Pesa B2B Kenya">M-Pesa Paybill / Daraja API (Kenya)</option>
                  <option value="UPI AutoPay India">UPI 2.0 / Bharat Agri Rail (India)</option>
                  <option value="Pix Brazil Instant">Pix Banco Central do Brasil (Brazil)</option>
                  <option value="SWIFT International Wire">SWIFT / International USD Wire</option>
                </select>
              </div>

              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 text-xs text-stone-600 space-y-1">
                <div className="font-semibold text-stone-900">Real-Time Treasury Credit</div>
                <p className="text-[11px]">
                  Funds will be credited immediately to your trading escrow account with 0% platform deposit surcharge.
                </p>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-xl transition-colors cursor-pointer shadow-xs"
              >
                Simulate Instant Deposit
              </button>
            </form>
          )}

          {activeTab === 'withdraw' && (
            <form onSubmit={handleWithdrawSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Withdrawal Amount (USD) *
                </label>
                <input
                  type="number"
                  min={50}
                  max={availableBalanceUsd}
                  value={withdrawAmount}
                  onChange={(e) => setWithdrawAmount(Number(e.target.value))}
                  className="w-full text-sm font-mono p-3 border border-stone-200 rounded-xl focus:ring-2 focus:ring-emerald-600/20"
                />
                <div className="text-[11px] text-stone-500 mt-1 font-mono">
                  Max available: {formatCurrency(availableBalanceUsd, currency)}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Beneficiary Payout Destination
                </label>
                <input
                  type="text"
                  required
                  value={withdrawDestination}
                  onChange={(e) => setWithdrawDestination(e.target.value)}
                  className="w-full text-xs p-3 border border-stone-200 rounded-xl"
                  placeholder="e.g. Cooperative Bank Account or M-Pesa Phone #"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold rounded-xl transition-colors cursor-pointer shadow-xs"
              >
                Execute Payout Transfer
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
