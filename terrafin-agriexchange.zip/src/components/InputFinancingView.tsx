import React, { useState } from 'react';
import { InputLoanApplication, InputPackage, RegionCorridor, Currency } from '../types';
import { formatCurrency, formatNumber } from '../utils/formatters';
import { Sprout, CheckCircle, ShieldCheck, ChevronRight, Zap, CreditCard, Sparkles, Building2, Calendar } from 'lucide-react';

interface InputFinancingViewProps {
  loans: InputLoanApplication[];
  packages: InputPackage[];
  activeCorridor: RegionCorridor;
  currency: Currency;
  onApplyLoan: (application: Omit<InputLoanApplication, 'id' | 'appliedDate' | 'status' | 'creditScore' | 'creditFactors'>) => void;
  onRepayLoan: (loanId: string) => void;
}

export function InputFinancingView({
  loans,
  packages,
  activeCorridor,
  currency,
  onApplyLoan,
  onRepayLoan,
}: InputFinancingViewProps) {
  const [selectedPackageId, setSelectedPackageId] = useState<string>(packages[0]?.id || 'PKG-AF-01');
  const [farmerName, setFarmerName] = useState('Samuel Kipchoge Chebet');
  const [nationalKyc, setNationalKyc] = useState('KE-ID-99214012');
  const [cooperativeName, setCooperativeName] = useState('Nakuru Smallholder Cereals Federation');
  const [corridor, setCorridor] = useState<'africa' | 'india' | 'latam'>('africa');
  const [hectares, setHectares] = useState<number>(3.5);
  const [tenureMonths, setTenureMonths] = useState<number>(6);
  const [repaymentType, setRepaymentType] = useState<'bullet_harvest' | 'monthly_equal'>('bullet_harvest');
  const [disbursalDest, setDisbursalDest] = useState<'agro_dealer_voucher' | 'mobile_money' | 'bank_account'>('agro_dealer_voucher');
  const [accountDetails, setAccountDetails] = useState('Kenya Farmers Association (KFA) Nakuru Depot');
  const [showApplySuccess, setShowApplySuccess] = useState(false);

  const selectedPackage = packages.find((p) => p.id === selectedPackageId) || packages[0];
  const principalUsd = selectedPackage ? selectedPackage.costPerHectareUsd * hectares : 500;
  const annualInterestRate = corridor === 'india' ? 6.8 : corridor === 'africa' ? 7.2 : 7.8;
  const interestAmountUsd = principalUsd * (annualInterestRate / 100) * (tenureMonths / 12);
  const totalRepaymentUsd = principalUsd + interestAmountUsd;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onApplyLoan({
      farmerName,
      nationalIdOrKyc: nationalKyc,
      cooperativeName,
      corridor,
      country: corridor === 'africa' ? 'Kenya' : corridor === 'india' ? 'India' : 'Colombia',
      landSizeHectares: hectares,
      inputPackageId: selectedPackage.id,
      inputPackageName: selectedPackage.name,
      principalAmountUsd: principalUsd,
      interestRateAnnualPercent: annualInterestRate,
      tenureMonths,
      repaymentType,
      disbursalDestination: disbursalDest,
      disbursalAccountDetails: accountDetails,
      dueDate: '2027-03-30',
    });
    setShowApplySuccess(true);
    setTimeout(() => setShowApplySuccess(false), 5000);
  };

  const filteredLoans = loans.filter((l) => {
    if (activeCorridor !== 'all' && l.corridor !== activeCorridor) return false;
    return true;
  });

  return (
    <div className="space-y-8">
      {/* Narrative Header */}
      <div className="bg-stone-900 text-stone-100 rounded-2xl p-6 sm:p-8 border border-stone-800 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
        <div className="space-y-2 max-w-2xl">
          <div className="text-xs uppercase tracking-widest text-emerald-400 font-semibold">
            Alternative Credit & Agrometric Underwriting
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            Pre-Season Working Capital & Certified Input Credit
          </h2>
          <p className="text-xs sm:text-sm text-stone-300 leading-relaxed">
            Eliminates high-interest predatory moneylenders for smallholders in Africa, India, and LATAM. Loans are underwritten using satellite vegetation history (NDVI), peer cooperative guarantees, and harvest liens without demanding land title deeds.
          </p>
        </div>

        {/* Credit matrix stats */}
        <div className="grid grid-cols-2 gap-3 shrink-0">
          <div className="bg-stone-800/80 rounded-xl p-3 border border-stone-700/60">
            <div className="text-[11px] text-stone-400">Avg. Interest Rate</div>
            <div className="text-xl font-bold text-emerald-400 font-mono tabular-nums">7.2% / yr</div>
            <div className="text-[10px] text-stone-400">vs 35%+ local informal rates</div>
          </div>
          <div className="bg-stone-800/80 rounded-xl p-3 border border-stone-700/60">
            <div className="text-[11px] text-stone-400">Repayment Model</div>
            <div className="text-xl font-bold text-white font-mono">Bullet Harvest</div>
            <div className="text-[10px] text-stone-400">Pay when crops are sold</div>
          </div>
        </div>
      </div>

      {/* Main Two-Column Layout: Loan Calculator + Active Loans */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Interactive Loan Application & Calculator */}
        <div className="lg:col-span-6 bg-white border border-stone-200 rounded-2xl p-6 shadow-xs space-y-6">
          <div className="border-b border-stone-100 pb-4">
            <h3 className="text-lg font-bold text-stone-900">
              Apply for Pre-Season Input Credit
            </h3>
            <p className="text-xs text-stone-500 mt-1">
              Select verified input package and customize land size for instant agrometric underwriting.
            </p>
          </div>

          {showApplySuccess && (
            <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-900 space-y-1">
              <div className="font-bold flex items-center gap-1.5">
                <CheckCircle className="w-4 h-4 text-emerald-600" />
                <span>Input Loan Approved & Voucher Generated!</span>
              </div>
              <p className="text-emerald-800">
                Satellite NDVI check scored 805/850. The disbursal voucher has been queued for immediate redemption at the partner agro-dealer depot.
              </p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Select Input Package */}
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                Certified Input Package
              </label>
              <div className="space-y-2">
                {packages.map((pkg) => (
                  <label
                    key={pkg.id}
                    className={`block p-3 rounded-xl border text-xs cursor-pointer transition-all ${
                      selectedPackageId === pkg.id
                        ? 'border-emerald-600 bg-emerald-50/50 shadow-xs'
                        : 'border-stone-200 hover:border-stone-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <input
                          type="radio"
                          name="packageRadio"
                          checked={selectedPackageId === pkg.id}
                          onChange={() => {
                            setSelectedPackageId(pkg.id);
                            setCorridor(pkg.corridor);
                          }}
                          className="accent-emerald-600"
                        />
                        <span className="font-bold text-stone-900">{pkg.name}</span>
                      </div>
                      <span className="font-mono tabular-nums font-semibold text-stone-900">
                        {formatCurrency(pkg.costPerHectareUsd, currency)} / ha
                      </span>
                    </div>
                    <p className="text-stone-500 text-[11px] mt-1 pl-6">
                      {pkg.description}
                    </p>
                  </label>
                ))}
              </div>
            </div>

            {/* Farm Acreage Slider */}
            <div>
              <div className="flex justify-between items-center text-xs font-semibold text-stone-700 mb-1">
                <span>Farmed Land Area (Hectares)</span>
                <span className="font-mono text-emerald-800 font-bold text-sm">{hectares} ha</span>
              </div>
              <input
                type="range"
                min={1}
                max={25}
                step={0.5}
                value={hectares}
                onChange={(e) => setHectares(Number(e.target.value))}
                className="w-full accent-emerald-600 h-2 bg-stone-200 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[11px] text-stone-400 mt-1">
                <span>1 ha (Smallholder)</span>
                <span>12 ha</span>
                <span>25 ha (Medium grower)</span>
              </div>
            </div>

            {/* Farmer Identification */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                  Farmer Full Name *
                </label>
                <input
                  type="text"
                  required
                  value={farmerName}
                  onChange={(e) => setFarmerName(e.target.value)}
                  className="w-full text-xs p-2.5 border border-stone-200 rounded-lg focus:ring-2 focus:ring-emerald-600/20"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                  National ID / Aadhaar / Cédula *
                </label>
                <input
                  type="text"
                  required
                  value={nationalKyc}
                  onChange={(e) => setNationalKyc(e.target.value)}
                  className="w-full text-xs p-2.5 border border-stone-200 rounded-lg font-mono"
                />
              </div>
            </div>

            {/* Cooperative Attribution */}
            <div>
              <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                Registered Cooperative / FPO *
              </label>
              <input
                type="text"
                required
                value={cooperativeName}
                onChange={(e) => setCooperativeName(e.target.value)}
                className="w-full text-xs p-2.5 border border-stone-200 rounded-lg"
              />
            </div>

            {/* Disbursal Method Selection */}
            <div>
              <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                Disbursal Destination (Prevents diversion)
              </label>
              <div className="grid grid-cols-3 gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => {
                    setDisbursalDest('agro_dealer_voucher');
                    setAccountDetails('Partner Agro-Dealer Direct Voucher');
                  }}
                  className={`p-2 rounded-lg border text-center cursor-pointer transition-colors ${
                    disbursalDest === 'agro_dealer_voucher'
                      ? 'bg-stone-900 text-white font-semibold border-stone-900'
                      : 'bg-stone-50 border-stone-200 text-stone-700 hover:bg-stone-100'
                  }`}
                >
                  Agro Voucher
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setDisbursalDest('mobile_money');
                    setAccountDetails('M-Pesa / UPI: +254 712 990 123');
                  }}
                  className={`p-2 rounded-lg border text-center cursor-pointer transition-colors ${
                    disbursalDest === 'mobile_money'
                      ? 'bg-stone-900 text-white font-semibold border-stone-900'
                      : 'bg-stone-50 border-stone-200 text-stone-700 hover:bg-stone-100'
                  }`}
                >
                  Mobile Money
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setDisbursalDest('bank_account');
                    setAccountDetails('Direct Cooperative Escrow Sub-account');
                  }}
                  className={`p-2 rounded-lg border text-center cursor-pointer transition-colors ${
                    disbursalDest === 'bank_account'
                      ? 'bg-stone-900 text-white font-semibold border-stone-900'
                      : 'bg-stone-50 border-stone-200 text-stone-700 hover:bg-stone-100'
                  }`}
                >
                  Co-op Bank
                </button>
              </div>
            </div>

            {/* Financial Summary Box */}
            <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 space-y-2 text-xs">
              <div className="flex justify-between text-stone-600">
                <span>Principal Financing ({hectares} ha × {selectedPackage?.costPerHectareUsd} USD)</span>
                <span className="font-mono tabular-nums font-semibold text-stone-900">
                  {formatCurrency(principalUsd, currency)}
                </span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span>Subsidized Interest ({annualInterestRate}% p.a. for {tenureMonths} mos)</span>
                <span className="font-mono tabular-nums text-stone-700">
                  {formatCurrency(interestAmountUsd, currency)}
                </span>
              </div>
              <div className="border-t border-stone-200 pt-2 flex justify-between font-bold text-sm text-stone-900">
                <span>Total Due at Harvest:</span>
                <span className="font-mono tabular-nums text-emerald-800">
                  {formatCurrency(totalRepaymentUsd, currency)}
                </span>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer shadow-xs flex items-center justify-center gap-2"
            >
              <Zap className="w-3.5 h-3.5 text-emerald-200" />
              <span>Submit for Instant Satellite & Co-op Underwriting</span>
            </button>
          </form>
        </div>

        {/* Right Column: Alternative Credit Engine & Active Portfolio */}
        <div className="lg:col-span-6 space-y-6">
          {/* Alternative Credit Matrix Visual */}
          <div className="bg-white border border-stone-200 rounded-2xl p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div>
                <h4 className="font-bold text-stone-900 text-sm">
                  Alternative Agrometric Credit Scoring Model
                </h4>
                <p className="text-[11px] text-stone-500">
                  How loans are approved in &lt; 90 seconds without traditional collateral
                </p>
              </div>
              <div className="px-2.5 py-1 bg-emerald-50 text-emerald-800 font-mono text-xs font-bold rounded-lg border border-emerald-200">
                Score: 795 / 850
              </div>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <div className="flex justify-between text-stone-700 font-medium mb-1">
                  <span>Satellite NDVI Vegetation Health (3-Year Consistency)</span>
                  <span className="font-mono tabular-nums font-semibold text-emerald-700">95% (High Yield)</span>
                </div>
                <div className="w-full bg-stone-100 h-2 rounded-full overflow-hidden">
                  <div className="bg-emerald-600 h-full rounded-full" style={{ width: '95%' }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-stone-700 font-medium mb-1">
                  <span>Cooperative Membership & Peer Endorsement Tenure</span>
                  <span className="font-mono tabular-nums font-semibold text-emerald-700">90% (5+ Years)</span>
                </div>
                <div className="w-full bg-stone-100 h-2 rounded-full overflow-hidden">
                  <div className="bg-emerald-600 h-full rounded-full" style={{ width: '90%' }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-stone-700 font-medium mb-1">
                  <span>Historical Harvest Delivery & Repayment Track</span>
                  <span className="font-mono tabular-nums font-semibold text-emerald-700">98% (Zero Default)</span>
                </div>
                <div className="w-full bg-stone-100 h-2 rounded-full overflow-hidden">
                  <div className="bg-emerald-600 h-full rounded-full" style={{ width: '98%' }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-stone-700 font-medium mb-1">
                  <span>Soil Chemistry & Moisture Sensor Index</span>
                  <span className="font-mono tabular-nums font-semibold text-emerald-700">84% (Optimal NPK)</span>
                </div>
                <div className="w-full bg-stone-100 h-2 rounded-full overflow-hidden">
                  <div className="bg-emerald-600 h-full rounded-full" style={{ width: '84%' }} />
                </div>
              </div>
            </div>
          </div>

          {/* Active Loans Ledger */}
          <div className="bg-white border border-stone-200 rounded-2xl p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <h4 className="font-bold text-stone-900 text-sm">
                Active Input Financing Portfolio
              </h4>
              <span className="text-xs text-stone-500 font-mono">
                {filteredLoans.length} Loans Active
              </span>
            </div>

            <div className="space-y-4">
              {filteredLoans.map((loan) => (
                <div
                  key={loan.id}
                  className="p-4 rounded-xl border border-stone-200 bg-stone-50/60 space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-mono text-xs text-stone-500">{loan.id}</span>
                      <h5 className="font-bold text-stone-900 text-sm">{loan.farmerName}</h5>
                      <div className="text-[11px] text-stone-500">{loan.cooperativeName} ({loan.country})</div>
                    </div>

                    <div className="text-right">
                      <div className="text-[11px] text-stone-400">Principal</div>
                      <div className="font-mono font-bold text-stone-900 tabular-nums">
                        {formatCurrency(loan.principalAmountUsd, currency)}
                      </div>
                      <div className="text-[10px] text-emerald-700 font-semibold uppercase">
                        {loan.status}
                      </div>
                    </div>
                  </div>

                  <div className="text-xs text-stone-600 bg-white p-2.5 rounded-lg border border-stone-100 space-y-1">
                    <div className="flex justify-between">
                      <span>Package:</span>
                      <span className="font-medium text-stone-900">{loan.inputPackageName}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Harvest Due Date:</span>
                      <span className="font-mono text-stone-900">{loan.dueDate}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Credit Score:</span>
                      <span className="font-mono font-bold text-emerald-700">{loan.creditScore} / 850</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <span className="text-[11px] text-stone-500 truncate max-w-[200px]">
                      {loan.disbursalAccountDetails}
                    </span>

                    {loan.status !== 'repaid' ? (
                      <button
                        onClick={() => onRepayLoan(loan.id)}
                        className="px-3 py-1.5 bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                      >
                        Simulate Harvest Repayment
                      </button>
                    ) : (
                      <span className="text-xs font-semibold text-emerald-700 flex items-center gap-1">
                        <CheckCircle className="w-3.5 h-3.5" />
                        <span>Fully Settled</span>
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
