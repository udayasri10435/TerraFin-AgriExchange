import React from 'react';

interface CropVisualProps {
  category: 'coffee_cocoa' | 'grains_cereals' | 'oilseeds_pulses' | 'spices_specialty';
  cropName: string;
  className?: string;
}

export function CropVisual({ category, cropName, className = 'h-40 w-full' }: CropVisualProps) {
  const isCoffee = cropName.toLowerCase().includes('coffee');
  const isCocoa = cropName.toLowerCase().includes('cocoa');
  const isRiceOrWheat = cropName.toLowerCase().includes('rice') || cropName.toLowerCase().includes('wheat');
  const isTurmeric = cropName.toLowerCase().includes('turmeric');
  const isSoybean = cropName.toLowerCase().includes('soybean') || cropName.toLowerCase().includes('sesame');

  return (
    <div className={`relative overflow-hidden flex items-center justify-center ${className}`}>
      {/* Background with subtle grain texture and landscape contours */}
      {isCoffee && (
        <div className="absolute inset-0 bg-gradient-to-br from-emerald-950 via-stone-900 to-amber-950">
          <svg className="absolute inset-0 w-full h-full opacity-20" xmlns="http://www.w3.org/2000/svg">
            <path d="M0 60 Q 90 20, 180 60 T 360 60 L 360 140 L 0 140 Z" fill="#047857" />
            <path d="M0 80 Q 120 40, 240 80 T 480 80 L 480 140 L 0 140 Z" fill="#065f46" />
          </svg>
        </div>
      )}

      {isCocoa && (
        <div className="absolute inset-0 bg-gradient-to-br from-amber-950 via-stone-900 to-amber-900">
          <svg className="absolute inset-0 w-full h-full opacity-20" xmlns="http://www.w3.org/2000/svg">
            <path d="M0 70 Q 100 30, 200 70 T 400 70 L 400 140 L 0 140 Z" fill="#78350f" />
          </svg>
        </div>
      )}

      {isRiceOrWheat && (
        <div className="absolute inset-0 bg-gradient-to-br from-amber-900 via-stone-900 to-yellow-950">
          <svg className="absolute inset-0 w-full h-full opacity-20" xmlns="http://www.w3.org/2000/svg">
            <path d="M0 50 Q 80 10, 160 50 T 320 50 L 320 140 L 0 140 Z" fill="#b45309" />
          </svg>
        </div>
      )}

      {isTurmeric && (
        <div className="absolute inset-0 bg-gradient-to-br from-amber-800 via-stone-900 to-orange-950">
          <svg className="absolute inset-0 w-full h-full opacity-25" xmlns="http://www.w3.org/2000/svg">
            <circle cx="80" cy="40" r="60" fill="#ea580c" filter="blur(20px)" />
            <circle cx="260" cy="90" r="70" fill="#ca8a04" filter="blur(20px)" />
          </svg>
        </div>
      )}

      {isSoybean && (
        <div className="absolute inset-0 bg-gradient-to-br from-stone-900 via-emerald-950 to-stone-900">
          <svg className="absolute inset-0 w-full h-full opacity-20" xmlns="http://www.w3.org/2000/svg">
            <path d="M0 65 Q 110 35, 220 65 T 440 65 L 440 140 L 0 140 Z" fill="#15803d" />
          </svg>
        </div>
      )}

      {!isCoffee && !isCocoa && !isRiceOrWheat && !isTurmeric && !isSoybean && (
        <div className="absolute inset-0 bg-gradient-to-br from-stone-900 via-stone-800 to-emerald-950" />
      )}

      {/* Decorative agronomy SVG graphic */}
      <div className="relative z-10 flex flex-col items-center justify-center p-4 text-center">
        {isCoffee && (
          <div className="flex items-center gap-2 mb-2">
            <span className="w-4 h-4 rounded-full bg-rose-500 shadow-sm border border-rose-400 inline-block" />
            <span className="w-3.5 h-3.5 rounded-full bg-rose-600 shadow-sm border border-rose-400 inline-block" />
            <span className="w-4 h-4 rounded-full bg-rose-400 shadow-sm border border-rose-300 inline-block" />
            <span className="w-3 h-3 rounded-full bg-emerald-600 inline-block" />
          </div>
        )}

        {isCocoa && (
          <div className="flex items-center justify-center mb-2">
            <div className="w-12 h-6 rounded-full bg-amber-700 border-2 border-amber-600 shadow-inner rotate-[-15deg] flex items-center justify-center">
              <div className="w-8 h-0.5 bg-amber-900 opacity-60" />
            </div>
          </div>
        )}

        {isRiceOrWheat && (
          <div className="flex items-center gap-1 mb-2">
            <span className="w-1.5 h-6 bg-amber-400 rounded-full rotate-[-20deg]" />
            <span className="w-1.5 h-7 bg-amber-300 rounded-full" />
            <span className="w-1.5 h-6 bg-amber-400 rounded-full rotate-[20deg]" />
            <span className="w-1.5 h-5 bg-amber-500 rounded-full rotate-[35deg]" />
          </div>
        )}

        {isTurmeric && (
          <div className="flex items-center gap-1.5 mb-2">
            <span className="w-6 h-3 bg-amber-500 rounded-lg rotate-12" />
            <span className="w-8 h-3.5 bg-orange-500 rounded-lg -rotate-6" />
            <span className="w-5 h-3 bg-yellow-500 rounded-lg rotate-45" />
          </div>
        )}

        {isSoybean && (
          <div className="flex items-center gap-2 mb-2">
            <span className="w-3.5 h-3.5 rounded-full bg-amber-200 border border-amber-300 shadow-xs" />
            <span className="w-3.5 h-3.5 rounded-full bg-emerald-200 border border-emerald-300 shadow-xs" />
            <span className="w-3.5 h-3.5 rounded-full bg-amber-100 border border-amber-200 shadow-xs" />
          </div>
        )}

        <div className="text-xs uppercase tracking-widest text-stone-300 font-semibold mb-0.5">
          {category.replace('_', ' · ')}
        </div>
        <div className="text-sm font-semibold text-white drop-shadow-sm max-w-[240px] truncate">
          {cropName}
        </div>
      </div>

      {/* Grid overlay lines */}
      <div className="absolute inset-0 pointer-events-none bg-[linear-gradient(to_right,rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:24px_24px]" />
    </div>
  );
}

export function SatelliteRadarVisual({
  corridor,
  rainfallMm,
  ndvi,
  moisture,
  isTriggered = false,
}: {
  corridor: string;
  rainfallMm: number;
  ndvi: number;
  moisture: number;
  isTriggered?: boolean;
}) {
  return (
    <div className={`relative rounded-xl overflow-hidden p-5 border transition-all duration-300 ${
      isTriggered
        ? 'bg-rose-950/80 border-rose-500/60 shadow-lg shadow-rose-950/30'
        : 'bg-stone-900 border-stone-800'
    }`}>
      {/* Background radar grid */}
      <div className="absolute inset-0 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:16px_16px] opacity-15" />

      {/* Top telemetry row */}
      <div className="flex items-center justify-between text-xs text-stone-400 mb-4 relative z-10">
        <div className="flex items-center gap-2">
          <span className={`w-2 h-2 rounded-full ${isTriggered ? 'bg-rose-500 animate-ping' : 'bg-emerald-400 animate-pulse'}`} />
          <span className="font-mono uppercase tracking-wider text-stone-300">
            {isTriggered ? 'PARAMETRIC TRIGGER ACTIVE' : 'ORACLE TELEMETRY SYNC'}
          </span>
        </div>
        <span className="font-mono text-stone-400">CHIRPS · SENTINEL-2 · GPM</span>
      </div>

      {/* Interactive telemetry graphic */}
      <div className="relative z-10 grid grid-cols-3 gap-3 pt-2">
        <div className="bg-stone-800/80 rounded-lg p-3 border border-stone-700/60">
          <div className="text-[11px] text-stone-400 uppercase tracking-wider mb-1">Precipitation Index</div>
          <div className="font-mono text-xl font-bold text-white tabular-nums flex items-baseline gap-1">
            {rainfallMm.toFixed(1)} <span className="text-xs text-stone-400 font-normal">mm</span>
          </div>
          <div className="w-full bg-stone-700 h-1.5 rounded-full mt-2 overflow-hidden">
            <div
              className={`h-full transition-all duration-500 ${rainfallMm < 60 ? 'bg-amber-500' : 'bg-emerald-400'}`}
              style={{ width: `${Math.min(100, (rainfallMm / 150) * 100)}%` }}
            />
          </div>
        </div>

        <div className="bg-stone-800/80 rounded-lg p-3 border border-stone-700/60">
          <div className="text-[11px] text-stone-400 uppercase tracking-wider mb-1">NDVI Canopy Health</div>
          <div className="font-mono text-xl font-bold text-emerald-400 tabular-nums">
            {ndvi.toFixed(2)}
          </div>
          <div className="w-full bg-stone-700 h-1.5 rounded-full mt-2 overflow-hidden">
            <div
              className="h-full bg-emerald-500 transition-all duration-500"
              style={{ width: `${ndvi * 100}%` }}
            />
          </div>
        </div>

        <div className="bg-stone-800/80 rounded-lg p-3 border border-stone-700/60">
          <div className="text-[11px] text-stone-400 uppercase tracking-wider mb-1">Soil Saturation</div>
          <div className="font-mono text-xl font-bold text-sky-400 tabular-nums flex items-baseline gap-1">
            {moisture.toFixed(1)} <span className="text-xs text-stone-400 font-normal">%</span>
          </div>
          <div className="w-full bg-stone-700 h-1.5 rounded-full mt-2 overflow-hidden">
            <div
              className="h-full bg-sky-400 transition-all duration-500"
              style={{ width: `${Math.min(100, moisture * 2)}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
