import React, { useState } from 'react';
import { ProduceListing, RegionCorridor, Currency } from '../types';
import { formatCurrency, formatNumber } from '../utils/formatters';
import { CropVisual } from './VisualIllustrations';
import { Search, Filter, ShieldCheck, MapPin, Droplets, Award, Package, Plus, CheckCircle, X } from 'lucide-react';

interface MarketplaceViewProps {
  listings: ProduceListing[];
  activeCorridor: RegionCorridor;
  currency: Currency;
  onInitiateEscrow: (listing: ProduceListing, volumeMt: number) => void;
  onAddNewListing: (newListing: Omit<ProduceListing, 'id' | 'status'>) => void;
  isCreateModalOpen: boolean;
  setIsCreateModalOpen: (open: boolean) => void;
}

export function MarketplaceView({
  listings,
  activeCorridor,
  currency,
  onInitiateEscrow,
  onAddNewListing,
  isCreateModalOpen,
  setIsCreateModalOpen,
}: MarketplaceViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedListingForBid, setSelectedListingForBid] = useState<ProduceListing | null>(null);
  const [bidVolume, setBidVolume] = useState<number>(5);

  // New Listing Form State
  const [formCrop, setFormCrop] = useState('');
  const [formVariety, setFormVariety] = useState('');
  const [formCorridor, setFormCorridor] = useState<'africa' | 'india' | 'latam'>('africa');
  const [formCountry, setFormCountry] = useState('Kenya');
  const [formRegion, setFormRegion] = useState('Nyeri County');
  const [formFarmer, setFormFarmer] = useState('Rukira Coffee Cooperative');
  const [formCoop, setFormCoop] = useState('Othaya Farmers Society');
  const [formVolume, setFormVolume] = useState<number>(15);
  const [formMinOrder, setFormMinOrder] = useState<number>(2);
  const [formPriceUsd, setFormPriceUsd] = useState<number>(5400);
  const [formGrade, setFormGrade] = useState('Grade AA Specialty (88+)');
  const [formMoisture, setFormMoisture] = useState<number>(11.4);
  const [formCategory, setFormCategory] = useState<'coffee_cocoa' | 'grains_cereals' | 'oilseeds_pulses' | 'spices_specialty'>('coffee_cocoa');
  const [formHub, setFormHub] = useState('Nairobi Inland Container Depot');
  const [formDesc, setFormDesc] = useState('Hand-picked ripe harvest, moisture certified with third-party lab sample report.');

  // Filtering listings
  const filteredListings = listings.filter((item) => {
    // Corridor filter
    if (activeCorridor !== 'all' && item.corridor !== activeCorridor) {
      return false;
    }
    // Category filter
    if (selectedCategory !== 'all' && item.cropCategory !== selectedCategory) {
      return false;
    }
    // Search filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = item.cropName.toLowerCase().includes(q);
      const matchVariety = item.variety.toLowerCase().includes(q);
      const matchCountry = item.country.toLowerCase().includes(q);
      const matchCoop = item.cooperativeName.toLowerCase().includes(q);
      if (!matchName && !matchVariety && !matchCountry && !matchCoop) {
        return false;
      }
    }
    return true;
  });

  const handleOpenBidModal = (listing: ProduceListing) => {
    setSelectedListingForBid(listing);
    setBidVolume(Math.max(listing.minOrderMt, Math.min(listing.availableVolumeMt, 10)));
  };

  const handleConfirmBid = () => {
    if (!selectedListingForBid) return;
    onInitiateEscrow(selectedListingForBid, bidVolume);
    setSelectedListingForBid(null);
  };

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddNewListing({
      cropName: formCrop || 'Arabica Single Origin',
      variety: formVariety || 'Specialty Washed',
      corridor: formCorridor,
      country: formCountry,
      stateOrRegion: formRegion,
      farmerName: formFarmer,
      cooperativeName: formCoop,
      farmSizeHectares: 120,
      harvestDate: new Date().toISOString().split('T')[0],
      availableVolumeMt: Number(formVolume),
      minOrderMt: Number(formMinOrder),
      pricePerMtUsd: Number(formPriceUsd),
      qualityGrade: formGrade,
      moistureContentPercent: Number(formMoisture),
      certifications: ['FairTrade Certified', 'GAP Standards'],
      packagingType: '60kg Hermetic GrainPro Sacks',
      logisticsHub: formHub,
      cropCategory: formCategory,
      description: formDesc,
    });
    setIsCreateModalOpen(false);
  };

  return (
    <div className="space-y-8">
      {/* Controls Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-stone-400" />
          <input
            type="text"
            placeholder="Search crop, variety, country or cooperative..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-sm bg-white border border-stone-200 rounded-lg text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600 transition-all"
          />
        </div>

        {/* Category Filters (Functional Segmented Control) */}
        <div className="flex items-center gap-1 p-1 bg-stone-100 rounded-lg overflow-x-auto text-xs">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-3 py-1.5 font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
              selectedCategory === 'all'
                ? 'bg-white text-stone-900 shadow-xs font-semibold'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            All Crops
          </button>
          <button
            onClick={() => setSelectedCategory('coffee_cocoa')}
            className={`px-3 py-1.5 font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
              selectedCategory === 'coffee_cocoa'
                ? 'bg-white text-stone-900 shadow-xs font-semibold'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Coffee & Cacao
          </button>
          <button
            onClick={() => setSelectedCategory('grains_cereals')}
            className={`px-3 py-1.5 font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
              selectedCategory === 'grains_cereals'
                ? 'bg-white text-stone-900 shadow-xs font-semibold'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Grains & Rice
          </button>
          <button
            onClick={() => setSelectedCategory('oilseeds_pulses')}
            className={`px-3 py-1.5 font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
              selectedCategory === 'oilseeds_pulses'
                ? 'bg-white text-stone-900 shadow-xs font-semibold'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Soybeans & Oilseeds
          </button>
          <button
            onClick={() => setSelectedCategory('spices_specialty')}
            className={`px-3 py-1.5 font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
              selectedCategory === 'spices_specialty'
                ? 'bg-white text-stone-900 shadow-xs font-semibold'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Spices & High-Value
          </button>
        </div>

        {/* Action to add listing */}
        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="inline-flex items-center justify-center gap-1.5 px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap shadow-xs"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>List Harvest Lot</span>
        </button>
      </div>

      {/* Produce Grid */}
      {filteredListings.length === 0 ? (
        <div className="bg-white border border-stone-200 rounded-xl p-12 text-center max-w-lg mx-auto">
          <Package className="w-10 h-10 text-stone-400 mx-auto mb-3" />
          <h3 className="text-base font-semibold text-stone-900 mb-1">No produce listings found</h3>
          <p className="text-xs text-stone-500 mb-4">
            Try adjusting your search criteria or switch corridor filters to see available harvest lots.
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedCategory('all');
            }}
            className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredListings.map((listing) => (
            <div
              key={listing.id}
              className="bg-white border border-stone-200 rounded-xl overflow-hidden shadow-xs hover:shadow-md transition-shadow flex flex-col justify-between"
            >
              <div>
                {/* Visual Header */}
                <CropVisual
                  category={listing.cropCategory}
                  cropName={listing.cropName}
                  className="h-44 w-full"
                />

                <div className="p-5 space-y-4">
                  {/* Clean unboxed metadata with separators (No pill badges) */}
                  <div className="flex items-center gap-2 text-xs text-stone-500">
                    <span className="font-semibold text-stone-700 uppercase tracking-wider">{listing.country}</span>
                    <span aria-hidden="true">·</span>
                    <span>{listing.stateOrRegion}</span>
                    <span aria-hidden="true">·</span>
                    <span className="capitalize">{listing.corridor}</span>
                  </div>

                  {/* Title and Variety */}
                  <div>
                    <h3 className="text-lg font-bold text-stone-900 leading-snug">
                      {listing.cropName}
                    </h3>
                    <p className="text-xs text-stone-600 mt-0.5 font-medium">
                      {listing.variety}
                    </p>
                  </div>

                  {/* Cooperative & Farmer attribution */}
                  <div className="text-xs text-stone-600 bg-stone-50 p-2.5 rounded-lg border border-stone-100 space-y-1">
                    <div className="font-medium text-stone-900 truncate">
                      {listing.cooperativeName}
                    </div>
                    <div className="text-stone-500 text-[11px] truncate">
                      Origin: {listing.farmerName} ({listing.farmSizeHectares} ha collective)
                    </div>
                  </div>

                  {/* Agricultural Specs Grid */}
                  <div className="grid grid-cols-2 gap-2 text-xs pt-1">
                    <div className="flex items-center gap-1.5 text-stone-600">
                      <Droplets className="w-3.5 h-3.5 text-sky-600 shrink-0" />
                      <span>Moisture: <strong className="text-stone-900 font-mono tabular-nums">{listing.moistureContentPercent}%</strong></span>
                    </div>
                    <div className="flex items-center gap-1.5 text-stone-600">
                      <Award className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                      <span className="truncate" title={listing.qualityGrade}>
                        {listing.qualityGrade}
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5 text-stone-600">
                      <Package className="w-3.5 h-3.5 text-stone-500 shrink-0" />
                      <span>Avail: <strong className="text-stone-900 font-mono tabular-nums">{listing.availableVolumeMt} MT</strong></span>
                    </div>
                    <div className="flex items-center gap-1.5 text-stone-600">
                      <MapPin className="w-3.5 h-3.5 text-stone-500 shrink-0" />
                      <span className="truncate" title={listing.logisticsHub}>
                        {listing.logisticsHub}
                      </span>
                    </div>
                  </div>

                  {/* Certifications (unboxed text list) */}
                  <div className="text-[11px] text-stone-500 flex flex-wrap items-center gap-1 pt-1">
                    <span className="text-stone-400">Certifications:</span>
                    {listing.certifications.map((cert, idx) => (
                      <React.Fragment key={cert}>
                        <span className="text-stone-700 font-medium">{cert}</span>
                        {idx < listing.certifications.length - 1 && <span aria-hidden="true">·</span>}
                      </React.Fragment>
                    ))}
                  </div>
                </div>
              </div>

              {/* Bottom Price & Purchase CTA */}
              <div className="px-5 py-4 bg-stone-50/80 border-t border-stone-200 flex items-center justify-between gap-3">
                <div>
                  <div className="text-[11px] text-stone-500 uppercase tracking-wider">Spot Price / MT</div>
                  <div className="text-base font-bold text-stone-900 font-mono tabular-nums">
                    {formatCurrency(listing.pricePerMtUsd, currency)}
                  </div>
                  {currency !== 'USD' && (
                    <div className="text-[10px] text-stone-400 font-mono tabular-nums">
                      ${formatNumber(listing.pricePerMtUsd)} USD
                    </div>
                  )}
                </div>

                <button
                  onClick={() => handleOpenBidModal(listing)}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer shadow-xs whitespace-nowrap flex items-center gap-1.5"
                >
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-200" />
                  <span>Lock Escrow Bid</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Escrow Bid / Purchase Modal */}
      {selectedListingForBid && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-xl w-full border border-stone-200 shadow-2xl overflow-hidden">
            <div className="px-6 py-4 border-b border-stone-200 flex items-center justify-between bg-stone-50">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-700" />
                <h3 className="font-bold text-base text-stone-900">
                  Initiate Smart Escrow Trade Contract
                </h3>
              </div>
              <button
                onClick={() => setSelectedListingForBid(null)}
                className="text-stone-400 hover:text-stone-700 p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 space-y-5">
              {/* Product summary */}
              <div className="bg-stone-50 rounded-xl p-4 border border-stone-100 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-stone-900">{selectedListingForBid.cropName}</span>
                  <span className="text-xs text-stone-500 font-mono tabular-nums">
                    {formatCurrency(selectedListingForBid.pricePerMtUsd, currency)} / MT
                  </span>
                </div>
                <div className="text-xs text-stone-500">
                  Cooperative: {selectedListingForBid.cooperativeName} ({selectedListingForBid.country})
                </div>
                <div className="text-xs text-stone-500">
                  Moisture: {selectedListingForBid.moistureContentPercent}% · Grade: {selectedListingForBid.qualityGrade}
                </div>
              </div>

              {/* Volume Selection */}
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                  Order Volume (Metric Tonnes):
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="range"
                    min={selectedListingForBid.minOrderMt}
                    max={selectedListingForBid.availableVolumeMt}
                    step={1}
                    value={bidVolume}
                    onChange={(e) => setBidVolume(Number(e.target.value))}
                    className="flex-1 accent-emerald-600 h-2 bg-stone-200 rounded-lg cursor-pointer"
                  />
                  <div className="flex items-center gap-1 font-mono text-sm font-bold text-stone-900 bg-stone-100 px-3 py-1.5 rounded-lg border border-stone-200">
                    <input
                      type="number"
                      min={selectedListingForBid.minOrderMt}
                      max={selectedListingForBid.availableVolumeMt}
                      value={bidVolume}
                      onChange={(e) => setBidVolume(Number(e.target.value))}
                      className="w-14 text-right bg-transparent focus:outline-none"
                    />
                    <span>MT</span>
                  </div>
                </div>
                <div className="flex justify-between text-[11px] text-stone-400 mt-1">
                  <span>Min order: {selectedListingForBid.minOrderMt} MT</span>
                  <span>Total available: {selectedListingForBid.availableVolumeMt} MT</span>
                </div>
              </div>

              {/* Smart Contract Terms Breakdown */}
              <div className="bg-stone-50/80 rounded-xl p-4 border border-stone-200 space-y-2 text-xs">
                <div className="font-semibold text-stone-900 text-xs mb-1">
                  Settlement & Inspection Terms
                </div>
                <div className="flex justify-between text-stone-600">
                  <span>Gross Lot Value ({bidVolume} MT)</span>
                  <span className="font-mono tabular-nums font-semibold text-stone-900">
                    {formatCurrency(selectedListingForBid.pricePerMtUsd * bidVolume, currency)}
                  </span>
                </div>
                <div className="flex justify-between text-stone-600">
                  <span>Platform Escrow Fee (0.5%)</span>
                  <span className="font-mono tabular-nums text-stone-700">
                    {formatCurrency(selectedListingForBid.pricePerMtUsd * bidVolume * 0.005, currency)}
                  </span>
                </div>
                <div className="flex justify-between text-stone-600">
                  <span>Third-Party SGS / Moisture Inspection</span>
                  <span className="font-mono tabular-nums text-stone-700">Included</span>
                </div>
                <div className="border-t border-stone-200 pt-2 flex justify-between font-bold text-sm text-stone-900">
                  <span>Total Earnest Escrow Required:</span>
                  <span className="font-mono tabular-nums text-emerald-800">
                    {formatCurrency(selectedListingForBid.pricePerMtUsd * bidVolume * 1.005, currency)}
                  </span>
                </div>
              </div>

              {/* Escrow Mechanism Explanation */}
              <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200/60 text-xs text-emerald-950 space-y-1">
                <div className="font-semibold flex items-center gap-1.5">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                  <span>48-Hour Destination Inspection Protection</span>
                </div>
                <p className="text-[11px] leading-relaxed text-emerald-900">
                  Your funds are held securely in the TerraFin Smart Escrow Vault. Funds will NOT be disbursed to the cooperative until the produce is inspected at the logistics hub and verified to match certified moisture content and grade.
                </p>
              </div>
            </div>

            <div className="px-6 py-4 bg-stone-50 border-t border-stone-200 flex items-center justify-end gap-3">
              <button
                onClick={() => setSelectedListingForBid(null)}
                className="px-4 py-2 text-xs font-semibold text-stone-700 hover:text-stone-900 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmBid}
                className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer shadow-xs flex items-center gap-2"
              >
                <ShieldCheck className="w-4 h-4 text-emerald-200" />
                <span>Deposit to Escrow Vault & Execute</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* List New Harvest Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-2xl w-full border border-stone-200 shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
            <div className="px-6 py-4 border-b border-stone-200 flex items-center justify-between bg-stone-50 shrink-0">
              <h3 className="font-bold text-base text-stone-900">
                List New Harvest Lot for Global Escrow Trading
              </h3>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="text-stone-400 hover:text-stone-700 p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="p-6 overflow-y-auto space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Crop Commodity Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. SL-28 Arabica Coffee"
                    value={formCrop}
                    onChange={(e) => setFormCrop(e.target.value)}
                    className="w-full text-xs p-2.5 border border-stone-200 rounded-lg focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Variety & Processing *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Fully Washed AA Screen 18"
                    value={formVariety}
                    onChange={(e) => setFormVariety(e.target.value)}
                    className="w-full text-xs p-2.5 border border-stone-200 rounded-lg focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Operating Corridor *
                  </label>
                  <select
                    value={formCorridor}
                    onChange={(e) => {
                      const c = e.target.value as 'africa' | 'india' | 'latam';
                      setFormCorridor(c);
                      if (c === 'africa') setFormCountry('Kenya');
                      if (c === 'india') setFormCountry('India');
                      if (c === 'latam') setFormCountry('Colombia');
                    }}
                    className="w-full text-xs p-2.5 border border-stone-200 rounded-lg focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600"
                  >
                    <option value="africa">East & West Africa</option>
                    <option value="india">India & Bharat</option>
                    <option value="latam">Latin America (LATAM)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Country & Region *
                  </label>
                  <input
                    type="text"
                    required
                    value={formCountry}
                    onChange={(e) => setFormCountry(e.target.value)}
                    className="w-full text-xs p-2.5 border border-stone-200 rounded-lg focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Cooperative / FPO Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Othaya Farmers Co-op"
                    value={formCoop}
                    onChange={(e) => setFormCoop(e.target.value)}
                    className="w-full text-xs p-2.5 border border-stone-200 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Logistics / Port Hub *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Dry Port Embakasi, Nairobi"
                    value={formHub}
                    onChange={(e) => setFormHub(e.target.value)}
                    className="w-full text-xs p-2.5 border border-stone-200 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Available Volume (MT) *
                  </label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={formVolume}
                    onChange={(e) => setFormVolume(Number(e.target.value))}
                    className="w-full text-xs p-2.5 border border-stone-200 rounded-lg font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Spot Price per MT (USD) *
                  </label>
                  <input
                    type="number"
                    required
                    min={100}
                    value={formPriceUsd}
                    onChange={(e) => setFormPriceUsd(Number(e.target.value))}
                    className="w-full text-xs p-2.5 border border-stone-200 rounded-lg font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Moisture Content (%) *
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    required
                    value={formMoisture}
                    onChange={(e) => setFormMoisture(Number(e.target.value))}
                    className="w-full text-xs p-2.5 border border-stone-200 rounded-lg font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Quality Grade & Spec *
                  </label>
                  <input
                    type="text"
                    required
                    value={formGrade}
                    onChange={(e) => setFormGrade(e.target.value)}
                    className="w-full text-xs p-2.5 border border-stone-200 rounded-lg"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Lot Description & Provenance
                </label>
                <textarea
                  rows={2}
                  value={formDesc}
                  onChange={(e) => setFormDesc(e.target.value)}
                  className="w-full text-xs p-2.5 border border-stone-200 rounded-lg"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-stone-600 hover:text-stone-900 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer shadow-xs"
                >
                  Publish Harvest Lot
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
