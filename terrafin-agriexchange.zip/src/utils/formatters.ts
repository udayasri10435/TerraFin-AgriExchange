import { Currency, ExchangeRates, RegionCorridor } from '../types';

export const CURRENT_EXCHANGE_RATES: ExchangeRates = {
  USD: 1,
  KES: 129.5,   // Kenyan Shilling
  INR: 83.9,    // Indian Rupee
  BRL: 5.45,    // Brazilian Real
  NGN: 1620.0,  // Nigerian Naira
  COP: 4180.0,  // Colombian Peso
};

export const CORRIDOR_CURRENCIES: Record<RegionCorridor, Currency[]> = {
  all: ['USD', 'KES', 'INR', 'BRL'],
  africa: ['USD', 'KES', 'NGN'],
  india: ['USD', 'INR'],
  latam: ['USD', 'BRL', 'COP'],
};

export const CORRIDOR_DETAILS = {
  all: {
    name: 'Global Pan-Corridor',
    subtitle: 'Africa, South Asia (India) & Latin America',
    countries: 'Kenya, India, Brazil, Nigeria, Colombia, Ghana, Peru',
    mainSeason: 'Cross-Hemisphere Active Trade',
  },
  africa: {
    name: 'Sub-Saharan Africa Corridor',
    subtitle: 'East & West African Smallholder Networks',
    countries: 'Kenya, Nigeria, Ghana, Tanzania',
    mainSeason: 'Short Rains Harvest & Main Crop Cocoa',
    rails: 'M-Pesa, Airtel Money, NIBSS Instant',
  },
  india: {
    name: 'India & South Asia Corridor',
    subtitle: 'Bharat Agri Cooperatives & FPOs',
    countries: 'Punjab, Maharashtra, Karnataka, Andhra Pradesh',
    mainSeason: 'Kharif Harvest & Rabi Sowing Window',
    rails: 'UPI 2.0, e-NAM Escrow, Direct DBT',
  },
  latam: {
    name: 'Latin America Corridor',
    subtitle: 'Andean & Cerrado Agricultural Cooperatives',
    countries: 'Brazil, Colombia, Peru, Mexico',
    mainSeason: 'Safra Main Harvest & Specialty Coffee Mitaca',
    rails: 'Pix Instant, SPEI, Bank Interbancario',
  },
};

export function convertUsdToCurrency(amountUsd: number, targetCurrency: Currency): number {
  const rate = CURRENT_EXCHANGE_RATES[targetCurrency] || 1;
  return amountUsd * rate;
}

export function formatCurrency(
  amountUsd: number,
  targetCurrency: Currency,
  includeSymbol: boolean = true
): string {
  const localVal = convertUsdToCurrency(amountUsd, targetCurrency);

  const formatterMap: Record<Currency, { locale: string; currency: string; symbol: string }> = {
    USD: { locale: 'en-US', currency: 'USD', symbol: '$' },
    KES: { locale: 'en-KE', currency: 'KES', symbol: 'KSh ' },
    INR: { locale: 'en-IN', currency: 'INR', symbol: '₹' },
    BRL: { locale: 'pt-BR', currency: 'BRL', symbol: 'R$ ' },
    NGN: { locale: 'en-NG', currency: 'NGN', symbol: '₦' },
    COP: { locale: 'es-CO', currency: 'COP', symbol: 'COL$ ' },
  };

  const config = formatterMap[targetCurrency] || formatterMap.USD;

  const formattedNum = new Intl.NumberFormat(config.locale, {
    minimumFractionDigits: targetCurrency === 'COP' || targetCurrency === 'KES' || targetCurrency === 'NGN' ? 0 : 2,
    maximumFractionDigits: targetCurrency === 'COP' || targetCurrency === 'KES' || targetCurrency === 'NGN' ? 0 : 2,
  }).format(localVal);

  return includeSymbol ? `${config.symbol}${formattedNum}` : formattedNum;
}

export function formatNumber(num: number, decimals: number = 0): string {
  return new Intl.NumberFormat('en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  }).format(num);
}
