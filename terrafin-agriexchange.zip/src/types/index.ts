export type RegionCorridor = 'all' | 'africa' | 'india' | 'latam';

export type Currency = 'USD' | 'KES' | 'INR' | 'BRL' | 'NGN' | 'COP';

export interface ExchangeRates {
  USD: number;
  KES: number; // ~130 KES / USD
  INR: number; // ~84 INR / USD
  BRL: number; // ~5.6 BRL / USD
  NGN: number; // ~1600 NGN / USD
  COP: number; // ~4200 COP / USD
}

export interface ProduceListing {
  id: string;
  cropName: string;
  variety: string;
  corridor: 'africa' | 'india' | 'latam';
  country: string;
  stateOrRegion: string;
  farmerName: string;
  cooperativeName: string;
  farmSizeHectares: number;
  harvestDate: string;
  availableVolumeMt: number;
  minOrderMt: number;
  pricePerMtUsd: number;
  qualityGrade: string; // e.g. "Specialty AA (88+)", "Grade 1 Export", "Organic Certified"
  moistureContentPercent: number; // e.g. 11.8%
  certifications: string[]; // e.g. ["FairTrade", "Rainforest Alliance", "GAP"]
  packagingType: string; // e.g. "60kg GrainPro Jute Bags", "Bulk Container Liner"
  logisticsHub: string; // e.g. "Dry Port Embakasi, Nairobi", "JNPT Port, Navi Mumbai", "Santos Dry Terminal"
  cropCategory: 'coffee_cocoa' | 'grains_cereals' | 'oilseeds_pulses' | 'spices_specialty';
  description: string;
  status: 'available' | 'under_contract' | 'sold_out';
}

export interface EscrowContract {
  id: string;
  listingId: string;
  cropName: string;
  volumeMt: number;
  buyerName: string;
  farmerName: string;
  cooperativeName: string;
  totalAmountUsd: number;
  currency: Currency;
  escrowStatus: 'deposit_locked' | 'in_transit' | 'quality_inspected' | 'disbursed_to_farmer';
  depositTimestamp: string;
  inspectionWindowHours: number;
  logisticsProvider: string;
  trackingNumber: string;
  moistureVerifiedPercent: number;
  gradeVerified: string;
  disbursedTimestamp?: string;
  notes: string;
}

export interface InputPackage {
  id: string;
  name: string;
  corridor: 'africa' | 'india' | 'latam';
  targetCrop: string;
  description: string;
  costPerHectareUsd: number;
  itemsIncluded: string[];
  partnerAgroDealer: string;
}

export interface InputLoanApplication {
  id: string;
  farmerName: string;
  nationalIdOrKyc: string;
  cooperativeName: string;
  corridor: 'africa' | 'india' | 'latam';
  country: string;
  landSizeHectares: number;
  inputPackageId: string;
  inputPackageName: string;
  principalAmountUsd: number;
  interestRateAnnualPercent: number;
  tenureMonths: number;
  repaymentType: 'bullet_harvest' | 'monthly_equal';
  status: 'pending' | 'approved' | 'disbursed' | 'repaid';
  disbursalDestination: 'agro_dealer_voucher' | 'mobile_money' | 'bank_account';
  disbursalAccountDetails: string;
  appliedDate: string;
  dueDate: string;
  creditScore: number; // 300 - 850
  creditFactors: {
    ndviConsistencyScore: number; // 0 - 100
    repaymentHistoryScore: number; // 0 - 100
    coopTenureScore: number; // 0 - 100
    soilHealthScore: number; // 0 - 100
  };
}

export interface ParametricPolicy {
  id: string;
  farmerOrCoopName: string;
  parcelLocation: string;
  corridor: 'africa' | 'india' | 'latam';
  country: string;
  cropInsured: string;
  hectares: number;
  triggerType: 'drought_deficit' | 'excess_rainfall_flood' | 'extreme_heat_stress';
  triggerThresholdDescription: string;
  triggerThresholdValue: number;
  currentObservedValue: number;
  indexUnit: string; // e.g. "mm cumulative rain", "mm 72h deluge", "°C consecutive days"
  sumInsuredUsd: number;
  premiumPaidUsd: number;
  subsidyRatePercent: number; // e.g. 50% government climate subsidy
  policyStart: string;
  policyEnd: string;
  status: 'active' | 'triggered_paid' | 'expired_safe';
  payoutAmountUsd?: number;
  payoutTxHash?: string;
  payoutTimestamp?: string;
}

export interface ClimateTelemetryData {
  district: string;
  country: string;
  corridor: 'africa' | 'india' | 'latam';
  soilMoisturePercent: number;
  currentSeasonalRainfallMm: number;
  normalSeasonalRainfallMm: number;
  currentNdviIndex: number; // 0.1 to 0.9
  baselineNdviIndex: number;
  surfaceTempCelsius: number;
  riskCondition: 'normal' | 'moderate_drought' | 'severe_drought' | 'excess_moisture';
  lastSatellitePass: string;
}

export interface WalletTransaction {
  id: string;
  timestamp: string;
  type: 'escrow_lock' | 'escrow_payout' | 'loan_disbursal' | 'loan_repayment' | 'insurance_claim' | 'deposit' | 'withdrawal';
  description: string;
  amountUsd: number;
  currency: Currency;
  localAmount: number;
  status: 'completed' | 'pending';
  referenceId: string;
  rail: 'M-Pesa Kenya' | 'UPI India' | 'Pix Brazil' | 'SWIFT/Wire' | 'Internal Escrow';
}

export interface CooperativeProfile {
  id: string;
  name: string;
  country: string;
  region: string;
  corridor: 'africa' | 'india' | 'latam';
  activeFarmersCount: number;
  totalHectares: number;
  primaryCrops: string[];
  certifications: string[];
  annualTonnageExported: number;
  yearEstablished: number;
  contactPerson: string;
  auditRating: string;
}
